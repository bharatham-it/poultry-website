-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 02, 2021 at 06:24 AM
-- Server version: 10.4.20-MariaDB
-- PHP Version: 7.3.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `poultry_web`
--

-- --------------------------------------------------------

--
-- Table structure for table `pd_commentmeta`
--

CREATE TABLE `pd_commentmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL,
  `comment_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pd_comments`
--

CREATE TABLE `pd_comments` (
  `comment_ID` bigint(20) UNSIGNED NOT NULL,
  `comment_post_ID` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `comment_author` tinytext COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT 0,
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'comment',
  `comment_parent` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `user_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pd_comments`
--

INSERT INTO `pd_comments` (`comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`) VALUES
(1, 1, 'A WordPress Commenter', 'wapuu@wordpress.example', 'https://wordpress.org/', '', '2021-08-13 05:58:54', '2021-08-13 05:58:54', 'Hi, this is a comment.\nTo get started with moderating, editing, and deleting comments, please visit the Comments screen in the dashboard.\nCommenter avatars come from <a href=\"https://gravatar.com\">Gravatar</a>.', 0, '1', '', 'comment', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `pd_links`
--

CREATE TABLE `pd_links` (
  `link_id` bigint(20) UNSIGNED NOT NULL,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) UNSIGNED NOT NULL DEFAULT 1,
  `link_rating` int(11) NOT NULL DEFAULT 0,
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pd_options`
--

CREATE TABLE `pd_options` (
  `option_id` bigint(20) UNSIGNED NOT NULL,
  `option_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'yes'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pd_options`
--

INSERT INTO `pd_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http://localhost/poultry-web/', 'yes'),
(2, 'home', 'http://localhost/poultry-web/', 'yes'),
(3, 'blogname', 'poultry-web', 'yes'),
(4, 'blogdescription', 'Just another WordPress site', 'yes'),
(5, 'users_can_register', '0', 'yes'),
(6, 'admin_email', 'sharon.bharathamitsolution@gmail.com', 'yes'),
(7, 'start_of_week', '1', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '10', 'yes'),
(13, 'rss_use_excerpt', '0', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'open', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '0', 'yes'),
(22, 'posts_per_page', '10', 'yes'),
(23, 'date_format', 'F j, Y', 'yes'),
(24, 'time_format', 'g:i a', 'yes'),
(25, 'links_updated_date_format', 'F j, Y g:i a', 'yes'),
(26, 'comment_moderation', '0', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '/%year%/%monthnum%/%day%/%postname%/', 'yes'),
(29, 'rewrite_rules', 'a:129:{s:11:\"^wp-json/?$\";s:22:\"index.php?rest_route=/\";s:14:\"^wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:21:\"^index.php/wp-json/?$\";s:22:\"index.php?rest_route=/\";s:24:\"^index.php/wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:17:\"^wp-sitemap\\.xml$\";s:23:\"index.php?sitemap=index\";s:17:\"^wp-sitemap\\.xsl$\";s:36:\"index.php?sitemap-stylesheet=sitemap\";s:23:\"^wp-sitemap-index\\.xsl$\";s:34:\"index.php?sitemap-stylesheet=index\";s:48:\"^wp-sitemap-([a-z]+?)-([a-z\\d_-]+?)-(\\d+?)\\.xml$\";s:75:\"index.php?sitemap=$matches[1]&sitemap-subtype=$matches[2]&paged=$matches[3]\";s:34:\"^wp-sitemap-([a-z]+?)-(\\d+?)\\.xml$\";s:47:\"index.php?sitemap=$matches[1]&paged=$matches[2]\";s:47:\"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:42:\"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:23:\"category/(.+?)/embed/?$\";s:46:\"index.php?category_name=$matches[1]&embed=true\";s:35:\"category/(.+?)/page/?([0-9]{1,})/?$\";s:53:\"index.php?category_name=$matches[1]&paged=$matches[2]\";s:17:\"category/(.+?)/?$\";s:35:\"index.php?category_name=$matches[1]\";s:44:\"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:39:\"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:20:\"tag/([^/]+)/embed/?$\";s:36:\"index.php?tag=$matches[1]&embed=true\";s:32:\"tag/([^/]+)/page/?([0-9]{1,})/?$\";s:43:\"index.php?tag=$matches[1]&paged=$matches[2]\";s:14:\"tag/([^/]+)/?$\";s:25:\"index.php?tag=$matches[1]\";s:45:\"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:40:\"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:21:\"type/([^/]+)/embed/?$\";s:44:\"index.php?post_format=$matches[1]&embed=true\";s:33:\"type/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?post_format=$matches[1]&paged=$matches[2]\";s:15:\"type/([^/]+)/?$\";s:33:\"index.php?post_format=$matches[1]\";s:40:\"testimonials/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:50:\"testimonials/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:70:\"testimonials/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:65:\"testimonials/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:65:\"testimonials/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:46:\"testimonials/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:29:\"testimonials/([^/]+)/embed/?$\";s:45:\"index.php?testimonials=$matches[1]&embed=true\";s:33:\"testimonials/([^/]+)/trackback/?$\";s:39:\"index.php?testimonials=$matches[1]&tb=1\";s:41:\"testimonials/([^/]+)/page/?([0-9]{1,})/?$\";s:52:\"index.php?testimonials=$matches[1]&paged=$matches[2]\";s:48:\"testimonials/([^/]+)/comment-page-([0-9]{1,})/?$\";s:52:\"index.php?testimonials=$matches[1]&cpage=$matches[2]\";s:37:\"testimonials/([^/]+)(?:/([0-9]+))?/?$\";s:51:\"index.php?testimonials=$matches[1]&page=$matches[2]\";s:29:\"testimonials/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:39:\"testimonials/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:59:\"testimonials/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:54:\"testimonials/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:54:\"testimonials/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:35:\"testimonials/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:32:\"team/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:42:\"team/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:62:\"team/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:57:\"team/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:57:\"team/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:38:\"team/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:21:\"team/([^/]+)/embed/?$\";s:37:\"index.php?team=$matches[1]&embed=true\";s:25:\"team/([^/]+)/trackback/?$\";s:31:\"index.php?team=$matches[1]&tb=1\";s:33:\"team/([^/]+)/page/?([0-9]{1,})/?$\";s:44:\"index.php?team=$matches[1]&paged=$matches[2]\";s:40:\"team/([^/]+)/comment-page-([0-9]{1,})/?$\";s:44:\"index.php?team=$matches[1]&cpage=$matches[2]\";s:29:\"team/([^/]+)(?:/([0-9]+))?/?$\";s:43:\"index.php?team=$matches[1]&page=$matches[2]\";s:21:\"team/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:31:\"team/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:51:\"team/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:46:\"team/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:46:\"team/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:27:\"team/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:48:\".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$\";s:18:\"index.php?feed=old\";s:20:\".*wp-app\\.php(/.*)?$\";s:19:\"index.php?error=403\";s:18:\".*wp-register.php$\";s:23:\"index.php?register=true\";s:32:\"feed/(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:27:\"(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:8:\"embed/?$\";s:21:\"index.php?&embed=true\";s:20:\"page/?([0-9]{1,})/?$\";s:28:\"index.php?&paged=$matches[1]\";s:27:\"comment-page-([0-9]{1,})/?$\";s:38:\"index.php?&page_id=6&cpage=$matches[1]\";s:41:\"comments/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:36:\"comments/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:17:\"comments/embed/?$\";s:21:\"index.php?&embed=true\";s:44:\"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:39:\"search/(.+)/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:20:\"search/(.+)/embed/?$\";s:34:\"index.php?s=$matches[1]&embed=true\";s:32:\"search/(.+)/page/?([0-9]{1,})/?$\";s:41:\"index.php?s=$matches[1]&paged=$matches[2]\";s:14:\"search/(.+)/?$\";s:23:\"index.php?s=$matches[1]\";s:47:\"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:42:\"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:23:\"author/([^/]+)/embed/?$\";s:44:\"index.php?author_name=$matches[1]&embed=true\";s:35:\"author/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?author_name=$matches[1]&paged=$matches[2]\";s:17:\"author/([^/]+)/?$\";s:33:\"index.php?author_name=$matches[1]\";s:69:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:64:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:45:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$\";s:74:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true\";s:57:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:81:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]\";s:39:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$\";s:63:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]\";s:56:\"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:51:\"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:32:\"([0-9]{4})/([0-9]{1,2})/embed/?$\";s:58:\"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true\";s:44:\"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:65:\"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]\";s:26:\"([0-9]{4})/([0-9]{1,2})/?$\";s:47:\"index.php?year=$matches[1]&monthnum=$matches[2]\";s:43:\"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:38:\"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:19:\"([0-9]{4})/embed/?$\";s:37:\"index.php?year=$matches[1]&embed=true\";s:31:\"([0-9]{4})/page/?([0-9]{1,})/?$\";s:44:\"index.php?year=$matches[1]&paged=$matches[2]\";s:13:\"([0-9]{4})/?$\";s:26:\"index.php?year=$matches[1]\";s:58:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:68:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:88:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:83:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:83:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:64:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:53:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/embed/?$\";s:91:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&embed=true\";s:57:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/trackback/?$\";s:85:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&tb=1\";s:77:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:97:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]\";s:72:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:97:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]\";s:65:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/page/?([0-9]{1,})/?$\";s:98:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&paged=$matches[5]\";s:72:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/comment-page-([0-9]{1,})/?$\";s:98:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&cpage=$matches[5]\";s:61:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)(?:/([0-9]+))?/?$\";s:97:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&page=$matches[5]\";s:47:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:57:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:77:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:72:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:72:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:53:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:64:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$\";s:81:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&cpage=$matches[4]\";s:51:\"([0-9]{4})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$\";s:65:\"index.php?year=$matches[1]&monthnum=$matches[2]&cpage=$matches[3]\";s:38:\"([0-9]{4})/comment-page-([0-9]{1,})/?$\";s:44:\"index.php?year=$matches[1]&cpage=$matches[2]\";s:27:\".?.+?/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:37:\".?.+?/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:57:\".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:33:\".?.+?/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:16:\"(.?.+?)/embed/?$\";s:41:\"index.php?pagename=$matches[1]&embed=true\";s:20:\"(.?.+?)/trackback/?$\";s:35:\"index.php?pagename=$matches[1]&tb=1\";s:40:\"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:35:\"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:28:\"(.?.+?)/page/?([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&paged=$matches[2]\";s:35:\"(.?.+?)/comment-page-([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&cpage=$matches[2]\";s:24:\"(.?.+?)(?:/([0-9]+))?/?$\";s:47:\"index.php?pagename=$matches[1]&page=$matches[2]\";}', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:3:{i:0;s:47:\"better-search-replace/better-search-replace.php\";i:1;s:47:\"show-current-template/show-current-template.php\";i:2;s:34:\"vw-mobile-app-pro-plugin/index.php\";}', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(36, 'comment_max_links', '2', 'yes'),
(37, 'gmt_offset', '0', 'yes'),
(38, 'default_email_category', '1', 'yes'),
(39, 'recently_edited', '', 'no'),
(40, 'template', 'sirat', 'yes'),
(41, 'stylesheet', 'sirat', 'yes'),
(42, 'comment_registration', '0', 'yes'),
(43, 'html_type', 'text/html', 'yes'),
(44, 'use_trackback', '0', 'yes'),
(45, 'default_role', 'subscriber', 'yes'),
(46, 'db_version', '49752', 'yes'),
(47, 'uploads_use_yearmonth_folders', '1', 'yes'),
(48, 'upload_path', '', 'yes'),
(49, 'blog_public', '0', 'yes'),
(50, 'default_link_category', '2', 'yes'),
(51, 'show_on_front', 'page', 'yes'),
(52, 'tag_base', '', 'yes'),
(53, 'show_avatars', '1', 'yes'),
(54, 'avatar_rating', 'G', 'yes'),
(55, 'upload_url_path', '', 'yes'),
(56, 'thumbnail_size_w', '150', 'yes'),
(57, 'thumbnail_size_h', '150', 'yes'),
(58, 'thumbnail_crop', '1', 'yes'),
(59, 'medium_size_w', '300', 'yes'),
(60, 'medium_size_h', '300', 'yes'),
(61, 'avatar_default', 'mystery', 'yes'),
(62, 'large_size_w', '1024', 'yes'),
(63, 'large_size_h', '1024', 'yes'),
(64, 'image_default_link_type', 'none', 'yes'),
(65, 'image_default_size', '', 'yes'),
(66, 'image_default_align', '', 'yes'),
(67, 'close_comments_for_old_posts', '0', 'yes'),
(68, 'close_comments_days_old', '14', 'yes'),
(69, 'thread_comments', '1', 'yes'),
(70, 'thread_comments_depth', '5', 'yes'),
(71, 'page_comments', '0', 'yes'),
(72, 'comments_per_page', '50', 'yes'),
(73, 'default_comments_page', 'newest', 'yes'),
(74, 'comment_order', 'asc', 'yes'),
(75, 'sticky_posts', 'a:0:{}', 'yes'),
(76, 'widget_categories', 'a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}', 'yes'),
(77, 'widget_text', 'a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}', 'yes'),
(78, 'widget_rss', 'a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}', 'yes'),
(79, 'uninstall_plugins', 'a:0:{}', 'no'),
(80, 'timezone_string', '', 'yes'),
(81, 'page_for_posts', '0', 'yes'),
(82, 'page_on_front', '6', 'yes'),
(83, 'default_post_format', '0', 'yes'),
(84, 'link_manager_enabled', '0', 'yes'),
(85, 'finished_splitting_shared_terms', '1', 'yes'),
(86, 'site_icon', '0', 'yes'),
(87, 'medium_large_size_w', '768', 'yes'),
(88, 'medium_large_size_h', '0', 'yes'),
(89, 'wp_page_for_privacy_policy', '3', 'yes'),
(90, 'show_comments_cookies_opt_in', '1', 'yes'),
(91, 'admin_email_lifespan', '1644386325', 'yes'),
(92, 'disallowed_keys', '', 'no'),
(93, 'comment_previously_approved', '1', 'yes'),
(94, 'auto_plugin_theme_update_emails', 'a:0:{}', 'no'),
(95, 'auto_update_core_dev', 'enabled', 'yes'),
(96, 'auto_update_core_minor', 'enabled', 'yes'),
(97, 'auto_update_core_major', 'enabled', 'yes'),
(98, 'wp_force_deactivated_plugins', 'a:0:{}', 'yes'),
(99, 'initial_db_version', '49752', 'yes'),
(100, 'pd_user_roles', 'a:5:{s:13:\"administrator\";a:2:{s:4:\"name\";s:13:\"Administrator\";s:12:\"capabilities\";a:61:{s:13:\"switch_themes\";b:1;s:11:\"edit_themes\";b:1;s:16:\"activate_plugins\";b:1;s:12:\"edit_plugins\";b:1;s:10:\"edit_users\";b:1;s:10:\"edit_files\";b:1;s:14:\"manage_options\";b:1;s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:6:\"import\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:8:\"level_10\";b:1;s:7:\"level_9\";b:1;s:7:\"level_8\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:12:\"delete_users\";b:1;s:12:\"create_users\";b:1;s:17:\"unfiltered_upload\";b:1;s:14:\"edit_dashboard\";b:1;s:14:\"update_plugins\";b:1;s:14:\"delete_plugins\";b:1;s:15:\"install_plugins\";b:1;s:13:\"update_themes\";b:1;s:14:\"install_themes\";b:1;s:11:\"update_core\";b:1;s:10:\"list_users\";b:1;s:12:\"remove_users\";b:1;s:13:\"promote_users\";b:1;s:18:\"edit_theme_options\";b:1;s:13:\"delete_themes\";b:1;s:6:\"export\";b:1;}}s:6:\"editor\";a:2:{s:4:\"name\";s:6:\"Editor\";s:12:\"capabilities\";a:34:{s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;}}s:6:\"author\";a:2:{s:4:\"name\";s:6:\"Author\";s:12:\"capabilities\";a:10:{s:12:\"upload_files\";b:1;s:10:\"edit_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;s:22:\"delete_published_posts\";b:1;}}s:11:\"contributor\";a:2:{s:4:\"name\";s:11:\"Contributor\";s:12:\"capabilities\";a:5:{s:10:\"edit_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;}}s:10:\"subscriber\";a:2:{s:4:\"name\";s:10:\"Subscriber\";s:12:\"capabilities\";a:2:{s:4:\"read\";b:1;s:7:\"level_0\";b:1;}}}', 'yes'),
(101, 'fresh_site', '0', 'yes'),
(102, 'widget_block', 'a:6:{i:2;a:1:{s:7:\"content\";s:19:\"<!-- wp:search /-->\";}i:3;a:1:{s:7:\"content\";s:154:\"<!-- wp:group --><div class=\"wp-block-group\"><!-- wp:heading --><h2>Recent Posts</h2><!-- /wp:heading --><!-- wp:latest-posts /--></div><!-- /wp:group -->\";}i:4;a:1:{s:7:\"content\";s:227:\"<!-- wp:group --><div class=\"wp-block-group\"><!-- wp:heading --><h2>Recent Comments</h2><!-- /wp:heading --><!-- wp:latest-comments {\"displayAvatar\":false,\"displayDate\":false,\"displayExcerpt\":false} /--></div><!-- /wp:group -->\";}i:5;a:1:{s:7:\"content\";s:146:\"<!-- wp:group --><div class=\"wp-block-group\"><!-- wp:heading --><h2>Archives</h2><!-- /wp:heading --><!-- wp:archives /--></div><!-- /wp:group -->\";}i:6;a:1:{s:7:\"content\";s:150:\"<!-- wp:group --><div class=\"wp-block-group\"><!-- wp:heading --><h2>Categories</h2><!-- /wp:heading --><!-- wp:categories /--></div><!-- /wp:group -->\";}s:12:\"_multiwidget\";i:1;}', 'yes'),
(103, 'sidebars_widgets', 'a:18:{s:19:\"wp_inactive_widgets\";a:0:{}s:12:\"vw-sidebar-1\";a:0:{}s:12:\"vw-sidebar-2\";a:0:{}s:11:\"vw-footer-1\";a:0:{}s:11:\"vw-footer-2\";a:0:{}s:11:\"vw-footer-3\";a:0:{}s:11:\"vw-footer-4\";a:0:{}s:9:\"sidebar-1\";a:5:{i:0;s:7:\"block-2\";i:1;s:7:\"block-3\";i:2;s:7:\"block-4\";i:3;s:7:\"block-5\";i:4;s:7:\"block-6\";}s:9:\"sidebar-2\";a:0:{}s:9:\"sidebar-3\";a:0:{}s:8:\"footer-1\";a:0:{}s:8:\"footer-2\";a:0:{}s:8:\"footer-3\";a:0:{}s:8:\"footer-4\";a:0:{}s:12:\"social-links\";a:0:{}s:24:\"woocommerce-shop-sidebar\";a:0:{}s:26:\"woocommerce-single-sidebar\";a:0:{}s:13:\"array_version\";i:3;}', 'yes'),
(104, 'cron', 'a:7:{i:1630558738;a:1:{s:34:\"wp_privacy_delete_old_export_files\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"hourly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:3600;}}}i:1630562336;a:1:{s:32:\"recovery_mode_clean_expired_keys\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1630562338;a:4:{s:18:\"wp_https_detection\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:16:\"wp_version_check\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:17:\"wp_update_plugins\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:16:\"wp_update_themes\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1630562405;a:2:{s:19:\"wp_scheduled_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}s:25:\"delete_expired_transients\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1630562408;a:1:{s:30:\"wp_scheduled_auto_draft_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1630735137;a:1:{s:30:\"wp_site_health_scheduled_check\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"weekly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:604800;}}}s:7:\"version\";i:2;}', 'yes'),
(105, 'widget_pages', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(106, 'widget_calendar', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(107, 'widget_archives', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(108, 'widget_media_audio', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(109, 'widget_media_image', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(110, 'widget_media_gallery', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(111, 'widget_media_video', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(112, 'widget_meta', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(113, 'widget_search', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(114, 'widget_tag_cloud', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(115, 'widget_nav_menu', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(116, 'widget_custom_html', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(118, 'recovery_keys', 'a:0:{}', 'yes'),
(119, 'theme_mods_twentytwentyone', 'a:2:{s:18:\"custom_css_post_id\";i:-1;s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1628835238;s:4:\"data\";a:3:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:3:{i:0;s:7:\"block-2\";i:1;s:7:\"block-3\";i:2;s:7:\"block-4\";}s:9:\"sidebar-2\";a:2:{i:0;s:7:\"block-5\";i:1;s:7:\"block-6\";}}}}', 'yes'),
(120, 'https_detection_errors', 'a:1:{s:23:\"ssl_verification_failed\";a:1:{i:0;s:24:\"SSL verification failed.\";}}', 'yes'),
(121, '_site_transient_update_core', 'O:8:\"stdClass\":4:{s:7:\"updates\";a:1:{i:0;O:8:\"stdClass\":10:{s:8:\"response\";s:6:\"latest\";s:8:\"download\";s:57:\"https://downloads.wordpress.org/release/wordpress-5.8.zip\";s:6:\"locale\";s:5:\"en_US\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:57:\"https://downloads.wordpress.org/release/wordpress-5.8.zip\";s:10:\"no_content\";s:68:\"https://downloads.wordpress.org/release/wordpress-5.8-no-content.zip\";s:11:\"new_bundled\";s:69:\"https://downloads.wordpress.org/release/wordpress-5.8-new-bundled.zip\";s:7:\"partial\";s:0:\"\";s:8:\"rollback\";s:0:\"\";}s:7:\"current\";s:3:\"5.8\";s:7:\"version\";s:3:\"5.8\";s:11:\"php_version\";s:6:\"5.6.20\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"5.6\";s:15:\"partial_version\";s:0:\"\";}}s:12:\"last_checked\";i:1630556622;s:15:\"version_checked\";s:3:\"5.8\";s:12:\"translations\";a:0:{}}', 'no'),
(136, 'can_compress_scripts', '1', 'no'),
(147, 'finished_updating_comment_type', '1', 'yes'),
(149, '_site_transient_update_themes', 'O:8:\"stdClass\":5:{s:12:\"last_checked\";i:1630556626;s:7:\"checked\";a:4:{s:5:\"sirat\";s:5:\"0.8.4\";s:14:\"twentynineteen\";s:3:\"2.1\";s:12:\"twentytwenty\";s:3:\"1.8\";s:15:\"twentytwentyone\";s:3:\"1.4\";}s:8:\"response\";a:0:{}s:9:\"no_update\";a:4:{s:5:\"sirat\";a:6:{s:5:\"theme\";s:5:\"sirat\";s:11:\"new_version\";s:5:\"0.8.4\";s:3:\"url\";s:35:\"https://wordpress.org/themes/sirat/\";s:7:\"package\";s:53:\"https://downloads.wordpress.org/theme/sirat.0.8.4.zip\";s:8:\"requires\";b:0;s:12:\"requires_php\";s:6:\"7.2.14\";}s:14:\"twentynineteen\";a:6:{s:5:\"theme\";s:14:\"twentynineteen\";s:11:\"new_version\";s:3:\"2.1\";s:3:\"url\";s:44:\"https://wordpress.org/themes/twentynineteen/\";s:7:\"package\";s:60:\"https://downloads.wordpress.org/theme/twentynineteen.2.1.zip\";s:8:\"requires\";s:5:\"4.9.6\";s:12:\"requires_php\";s:5:\"5.2.4\";}s:12:\"twentytwenty\";a:6:{s:5:\"theme\";s:12:\"twentytwenty\";s:11:\"new_version\";s:3:\"1.8\";s:3:\"url\";s:42:\"https://wordpress.org/themes/twentytwenty/\";s:7:\"package\";s:58:\"https://downloads.wordpress.org/theme/twentytwenty.1.8.zip\";s:8:\"requires\";s:3:\"4.7\";s:12:\"requires_php\";s:5:\"5.2.4\";}s:15:\"twentytwentyone\";a:6:{s:5:\"theme\";s:15:\"twentytwentyone\";s:11:\"new_version\";s:3:\"1.4\";s:3:\"url\";s:45:\"https://wordpress.org/themes/twentytwentyone/\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/theme/twentytwentyone.1.4.zip\";s:8:\"requires\";s:3:\"5.3\";s:12:\"requires_php\";s:3:\"5.6\";}}s:12:\"translations\";a:0:{}}', 'no'),
(150, 'current_theme', 'Sirat', 'yes'),
(151, 'theme_mods_sirat', 'a:176:{i:0;b:0;s:18:\"nav_menu_locations\";a:0:{}s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1628835421;s:4:\"data\";a:11:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:3:{i:0;s:7:\"block-2\";i:1;s:7:\"block-3\";i:2;s:7:\"block-4\";}s:9:\"sidebar-2\";a:2:{i:0;s:7:\"block-5\";i:1;s:7:\"block-6\";}s:9:\"sidebar-3\";a:0:{}s:8:\"footer-1\";a:0:{}s:8:\"footer-2\";a:0:{}s:8:\"footer-3\";a:0:{}s:8:\"footer-4\";a:0:{}s:12:\"social-links\";a:0:{}s:24:\"woocommerce-shop-sidebar\";a:0:{}s:26:\"woocommerce-single-sidebar\";a:0:{}}}s:18:\"custom_css_post_id\";i:-1;s:59:\"vw_mobile_app_pro_plugin_section_ordering_settings_repeater\";s:146:\"main-banner,about-me,promo-banner,amazing-features,awesome-screenshot,plans-pricing,our-team,testimonial,record,newsletter,latest-posts,contact-us\";s:39:\"vw_mobile_app_pro_plugin_hi_first_color\";s:7:\"#128bcf\";s:40:\"vw_mobile_app_pro_plugin_hi_second_color\";s:7:\"#52565b\";s:50:\"vw_mobile_app_pro_plugin_main_banner_section_title\";s:28:\"Welcome To Joy\'s poultry app\";s:53:\"vw_mobile_app_pro_plugin_main_banner_section_subtitle\";s:152:\"Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s,\";s:52:\"vw_mobile_app_pro_plugin_main_banner_section_button1\";s:13:\"Tell Me More \";s:52:\"vw_mobile_app_pro_plugin_main_banner_section_button2\";s:10:\"Sign Me Up\";s:47:\"vw_mobile_app_pro_plugin_main_banner_rightimage\";s:68:\"http://localhost/poultry-web/wp-content/uploads/2021/08/mobile-1.png\";s:44:\"vw_mobile_app_pro_plugin_main_banner_bgimage\";s:96:\"http://localhost/poultry-web/wp-content/uploads/2021/08/indoors-chicken-farm-chicken-feeding.png\";s:44:\"vw_mobile_app_pro_plugin_about_section_title\";s:8:\"ABOUT US\";s:47:\"vw_mobile_app_pro_plugin_about_section_subtitle\";s:152:\"Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s,\";s:37:\"vw_mobile_app_pro_plugin_about_number\";s:1:\"3\";s:42:\"vw_mobile_app_pro_plugin_about_icon_image1\";s:110:\"http://localhost/poultry-web/wp-content/uploads/2021/08/272-2723071_gr-icons-text-black-chicken-02-rooster.png\";s:41:\"vw_mobile_app_pro_plugin_about_sec_title1\";s:4:\"FARM\";s:43:\"vw_mobile_app_pro_plugin_about_sec_details1\";s:93:\"Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has be\";s:44:\"vw_mobile_app_pro_plugin_about_sec_readmore1\";s:9:\"Read More\";s:42:\"vw_mobile_app_pro_plugin_about_icon_image2\";s:114:\"http://localhost/poultry-web/wp-content/uploads/2021/08/323-3236283_logistics-comments-supply-icon-png-clipart.png\";s:41:\"vw_mobile_app_pro_plugin_about_sec_title2\";s:6:\"SUPPLY\";s:43:\"vw_mobile_app_pro_plugin_about_sec_details2\";s:93:\"Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has be\";s:44:\"vw_mobile_app_pro_plugin_about_sec_readmore2\";s:9:\"Read More\";s:42:\"vw_mobile_app_pro_plugin_about_icon_image3\";s:119:\"http://localhost/poultry-web/wp-content/uploads/2021/08/523-5230105_discount-shop-png-icon-sale-png-transparent-png.png\";s:41:\"vw_mobile_app_pro_plugin_about_sec_title3\";s:11:\"SHOP & SALE\";s:43:\"vw_mobile_app_pro_plugin_about_sec_details3\";s:93:\"Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has be\";s:44:\"vw_mobile_app_pro_plugin_about_sec_readmore3\";s:9:\"Read More\";s:51:\"vw_mobile_app_pro_plugin_promo_banner_section_title\";s:31:\"QUICKLY ONE - CLICK APP INSATLL\";s:54:\"vw_mobile_app_pro_plugin_promo_banner_section_subtitle\";s:32:\"Lorem Ipsum is simply dummy text\";s:52:\"vw_mobile_app_pro_plugin_promo_banner_section_button\";s:11:\"GET THE APP\";s:51:\"vw_mobile_app_pro_plugin_promo_banner_bgimage_inner\";s:68:\"http://localhost/poultry-web/wp-content/uploads/2021/08/Group-24.png\";s:55:\"vw_mobile_app_pro_plugin_amazing_features_section_title\";s:11:\"APP FEATURE\";s:58:\"vw_mobile_app_pro_plugin_amazing_features_section_subtitle\";s:0:\"\";s:49:\"vw_mobile_app_pro_plugin_amazing_features_bgimage\";s:68:\"http://localhost/poultry-web/wp-content/uploads/2021/08/Group-25.png\";s:57:\"vw_mobile_app_pro_plugin_amazing_features_box_left_number\";s:1:\"3\";s:56:\"vw_mobile_app_pro_plugin_amazing_features_box_left_icon1\";s:21:\"far fa-object-ungroup\";s:57:\"vw_mobile_app_pro_plugin_amazing_features_box_left_title1\";s:15:\"CREATIVE DESIGN\";s:56:\"vw_mobile_app_pro_plugin_amazing_features_box_left_desc1\";s:61:\"Te obtinuit ut adepto satis somno aliisque institoribus iter.\";s:56:\"vw_mobile_app_pro_plugin_amazing_features_box_left_icon2\";s:11:\"fas fa-code\";s:57:\"vw_mobile_app_pro_plugin_amazing_features_box_left_title2\";s:15:\"CREATIVE DESIGN\";s:56:\"vw_mobile_app_pro_plugin_amazing_features_box_left_desc2\";s:61:\"Te obtinuit ut adepto satis somno aliisque institoribus iter.\";s:56:\"vw_mobile_app_pro_plugin_amazing_features_box_left_icon3\";s:17:\"fas fa-globe-asia\";s:57:\"vw_mobile_app_pro_plugin_amazing_features_box_left_title3\";s:15:\"CREATIVE DESIGN\";s:56:\"vw_mobile_app_pro_plugin_amazing_features_box_left_desc3\";s:61:\"Te obtinuit ut adepto satis somno aliisque institoribus iter.\";s:58:\"vw_mobile_app_pro_plugin_amazing_features_box_center_image\";s:63:\"http://localhost/poultry-web/wp-content/uploads/2021/08/005.png\";s:58:\"vw_mobile_app_pro_plugin_amazing_features_box_right_number\";s:1:\"3\";s:57:\"vw_mobile_app_pro_plugin_amazing_features_box_right_icon1\";s:15:\"fas fa-download\";s:58:\"vw_mobile_app_pro_plugin_amazing_features_box_right_title1\";s:15:\"CREATIVE DESIGN\";s:57:\"vw_mobile_app_pro_plugin_amazing_features_box_right_desc1\";s:61:\"Te obtinuit ut adepto satis somno aliisque institoribus iter.\";s:57:\"vw_mobile_app_pro_plugin_amazing_features_box_right_icon2\";s:12:\"fab fa-apple\";s:58:\"vw_mobile_app_pro_plugin_amazing_features_box_right_title2\";s:15:\"CREATIVE DESIGN\";s:57:\"vw_mobile_app_pro_plugin_amazing_features_box_right_desc2\";s:61:\"Te obtinuit ut adepto satis somno aliisque institoribus iter.\";s:57:\"vw_mobile_app_pro_plugin_amazing_features_box_right_icon3\";s:16:\"far fa-lightbulb\";s:58:\"vw_mobile_app_pro_plugin_amazing_features_box_right_title3\";s:15:\"CREATIVE DESIGN\";s:57:\"vw_mobile_app_pro_plugin_amazing_features_box_right_desc3\";s:61:\"Te obtinuit ut adepto satis somno aliisque institoribus iter.\";s:57:\"vw_mobile_app_pro_plugin_awesome_screenshot_section_title\";s:19:\"Awesome Screenshots\";s:60:\"vw_mobile_app_pro_plugin_awesome_screenshot_section_subtitle\";s:152:\"Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s,\";s:54:\"vw_mobile_app_pro_plugin_awesome_screenshot_box_number\";s:1:\"5\";s:50:\"vw_mobile_app_pro_plugin_awesome_screenshot_image1\";s:63:\"http://localhost/poultry-web/wp-content/uploads/2021/08/001.png\";s:50:\"vw_mobile_app_pro_plugin_awesome_screenshot_image2\";s:63:\"http://localhost/poultry-web/wp-content/uploads/2021/08/001.png\";s:50:\"vw_mobile_app_pro_plugin_awesome_screenshot_image3\";s:63:\"http://localhost/poultry-web/wp-content/uploads/2021/08/003.png\";s:50:\"vw_mobile_app_pro_plugin_awesome_screenshot_image4\";s:63:\"http://localhost/poultry-web/wp-content/uploads/2021/08/005.png\";s:50:\"vw_mobile_app_pro_plugin_awesome_screenshot_image5\";s:0:\"\";s:50:\"vw_mobile_app_pro_plugin_pricing_box_section_title\";s:12:\"APP FEATURES\";s:53:\"vw_mobile_app_pro_plugin_pricing_box_section_subtitle\";s:0:\"\";s:46:\"vw_mobile_app_pro_plugin_plans_pricing_bgimage\";s:68:\"http://localhost/poultry-web/wp-content/uploads/2021/08/Group-25.png\";s:43:\"vw_mobile_app_pro_plugin_pricing_box_number\";s:1:\"3\";s:43:\"vw_mobile_app_pro_plugin_pricing_box_title1\";s:13:\"features List\";s:46:\"vw_mobile_app_pro_plugin_pricing_box_subtitle1\";s:8:\"features\";s:43:\"vw_mobile_app_pro_plugin_pricing_box_price1\";s:8:\"features\";s:48:\"vw_mobile_app_pro_plugin_pricing_box_price_base1\";s:0:\"\";s:40:\"vw_mobile_app_pro_plugin_plan_box_text11\";s:29:\"features Listing will go here\";s:40:\"vw_mobile_app_pro_plugin_plan_box_text21\";s:29:\"features Listing will go here\";s:40:\"vw_mobile_app_pro_plugin_plan_box_text31\";s:29:\"features Listing will go here\";s:40:\"vw_mobile_app_pro_plugin_plan_box_text41\";s:29:\"features Listing will go here\";s:40:\"vw_mobile_app_pro_plugin_plan_box_text51\";s:29:\"features Listing will go here\";s:40:\"vw_mobile_app_pro_plugin_plan_box_text61\";s:29:\"features Listing will go here\";s:41:\"vw_mobile_app_pro_plugin_pricing_box_btn1\";s:11:\"Select Plan\";s:43:\"vw_mobile_app_pro_plugin_pricing_box_title2\";s:9:\"EXCLUSIVE\";s:46:\"vw_mobile_app_pro_plugin_pricing_box_subtitle2\";s:21:\"Extended user license\";s:43:\"vw_mobile_app_pro_plugin_pricing_box_price2\";s:4:\"$120\";s:48:\"vw_mobile_app_pro_plugin_pricing_box_price_base2\";s:8:\"Per Year\";s:40:\"vw_mobile_app_pro_plugin_plan_box_text12\";s:29:\"features Listing will go here\";s:40:\"vw_mobile_app_pro_plugin_plan_box_text22\";s:29:\"features Listing will go here\";s:40:\"vw_mobile_app_pro_plugin_plan_box_text32\";s:29:\"features Listing will go here\";s:40:\"vw_mobile_app_pro_plugin_plan_box_text42\";s:29:\"features Listing will go here\";s:40:\"vw_mobile_app_pro_plugin_plan_box_text52\";s:29:\"features Listing will go here\";s:40:\"vw_mobile_app_pro_plugin_plan_box_text62\";s:29:\"features Listing will go here\";s:41:\"vw_mobile_app_pro_plugin_pricing_box_btn2\";s:11:\"Select Plan\";s:43:\"vw_mobile_app_pro_plugin_pricing_box_title3\";s:7:\"PREMIUM\";s:46:\"vw_mobile_app_pro_plugin_pricing_box_subtitle3\";s:17:\"Multiuser License\";s:43:\"vw_mobile_app_pro_plugin_pricing_box_price3\";s:4:\"$210\";s:48:\"vw_mobile_app_pro_plugin_pricing_box_price_base3\";s:8:\"Per Year\";s:40:\"vw_mobile_app_pro_plugin_plan_box_text13\";s:29:\"features Listing will go here\";s:40:\"vw_mobile_app_pro_plugin_plan_box_text23\";s:29:\"features Listing will go here\";s:40:\"vw_mobile_app_pro_plugin_plan_box_text33\";s:29:\"features Listing will go here\";s:40:\"vw_mobile_app_pro_plugin_plan_box_text43\";s:29:\"features Listing will go here\";s:40:\"vw_mobile_app_pro_plugin_plan_box_text53\";s:29:\"features Listing will go here\";s:40:\"vw_mobile_app_pro_plugin_plan_box_text63\";s:29:\"features Listing will go here\";s:41:\"vw_mobile_app_pro_plugin_pricing_box_btn3\";s:11:\"Select Plan\";s:35:\"vw_mobile_app_pro_plugin_team_title\";s:15:\"OUR SCREENSHOTS\";s:34:\"vw_mobile_app_pro_plugin_team_desc\";s:152:\"Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s,\";s:42:\"vw_mobile_app_pro_plugin_testimonial_title\";s:13:\"HAPPY CLIENTS\";s:41:\"vw_mobile_app_pro_plugin_testimonial_desc\";s:152:\"Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s,\";s:48:\"vw_mobile_app_pro_plugin_our_testimonial_bgimage\";s:68:\"http://localhost/poultry-web/wp-content/uploads/2021/08/Group-25.png\";s:38:\"vw_mobile_app_pro_plugin_records_title\";s:7:\"RECORDS\";s:37:\"vw_mobile_app_pro_plugin_records_desc\";s:152:\"Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s,\";s:43:\"vw_mobile_app_pro_plugin_records_box_number\";s:1:\"4\";s:42:\"vw_mobile_app_pro_plugin_records_box_icon1\";s:12:\"far fa-smile\";s:43:\"vw_mobile_app_pro_plugin_records_box_title1\";s:3:\"450\";s:46:\"vw_mobile_app_pro_plugin_records_box_subtitle1\";s:13:\"Happy Clients\";s:42:\"vw_mobile_app_pro_plugin_records_box_icon2\";s:12:\"fas fa-check\";s:43:\"vw_mobile_app_pro_plugin_records_box_title2\";s:3:\"900\";s:46:\"vw_mobile_app_pro_plugin_records_box_subtitle2\";s:12:\"load arrived\";s:42:\"vw_mobile_app_pro_plugin_records_box_icon3\";s:12:\"fas fa-users\";s:43:\"vw_mobile_app_pro_plugin_records_box_title3\";s:2:\"30\";s:46:\"vw_mobile_app_pro_plugin_records_box_subtitle3\";s:5:\"staff\";s:42:\"vw_mobile_app_pro_plugin_records_box_icon4\";s:20:\"fas fa-hands-helping\";s:43:\"vw_mobile_app_pro_plugin_records_box_title4\";s:4:\"100%\";s:46:\"vw_mobile_app_pro_plugin_records_box_subtitle4\";s:12:\"Team support\";s:36:\"vw_mobile_app_pro_plugin_video_image\";s:98:\"http://localhost/poultry-web/wp-content/plugins/vw-mobile-app-pro-plugin/assets/images/videobg.png\";s:34:\"vw_mobile_app_pro_plugin_video_url\";s:41:\"https://www.youtube.com/embed/DTp5lL46yI0\";s:41:\"vw_mobile_app_pro_plugin_newsletter_title\";s:27:\"SUBSCRIBE TO OUR NEWSLETTER\";s:40:\"vw_mobile_app_pro_plugin_newsletter_desc\";s:51:\"No spam promise, only our latest news and freebies.\";s:45:\"vw_mobile_app_pro_plugin_newsletter_shortcode\";s:48:\"[contact-form-7 id=\"124\" title=\"Contact form 1\"]\";s:43:\"vw_mobile_app_pro_plugin_newsletter_bgimage\";s:96:\"http://localhost/poultry-web/wp-content/uploads/2021/08/indoors-chicken-farm-chicken-feeding.png\";s:41:\"vw_mobile_app_pro_plugin_latestpost_title\";s:11:\"LATEST NEWS\";s:40:\"vw_mobile_app_pro_plugin_latestpost_desc\";s:152:\"Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s,\";s:45:\"vw_mobile_app_pro_plugin_latestpost_read_more\";s:9:\"Read More\";s:45:\"vw_mobile_app_pro_plugin_our_partnersbg_color\";s:7:\"#f3f6fc\";s:44:\"vw_mobile_app_pro_plugin_our_partners_number\";s:1:\"5\";s:44:\"vw_mobile_app_pro_plugin_our_partners_image1\";s:108:\"http://localhost/poultry-web/wp-content/plugins/vw-mobile-app-pro-plugin/assets/images/sponsers/sponser1.jpg\";s:44:\"vw_mobile_app_pro_plugin_our_partners_image2\";s:108:\"http://localhost/poultry-web/wp-content/plugins/vw-mobile-app-pro-plugin/assets/images/sponsers/sponser2.jpg\";s:44:\"vw_mobile_app_pro_plugin_our_partners_image3\";s:108:\"http://localhost/poultry-web/wp-content/plugins/vw-mobile-app-pro-plugin/assets/images/sponsers/sponser3.jpg\";s:44:\"vw_mobile_app_pro_plugin_our_partners_image4\";s:108:\"http://localhost/poultry-web/wp-content/plugins/vw-mobile-app-pro-plugin/assets/images/sponsers/sponser4.jpg\";s:44:\"vw_mobile_app_pro_plugin_our_partners_image5\";s:108:\"http://localhost/poultry-web/wp-content/plugins/vw-mobile-app-pro-plugin/assets/images/sponsers/sponser5.jpg\";s:44:\"vw_mobile_app_pro_plugin_our_partners_image6\";s:108:\"http://localhost/poultry-web/wp-content/plugins/vw-mobile-app-pro-plugin/assets/images/sponsers/sponser6.jpg\";s:40:\"vw_mobile_app_pro_plugin_home_form_title\";s:10:\"CONTACT US\";s:51:\"vw_mobile_app_pro_plugin_conntact_us_form_shortcode\";s:26:\"Add Contact Form shortcode\";s:38:\"vw_mobile_app_pro_plugin_headertwitter\";s:20:\"https://twitter.com/\";s:39:\"vw_mobile_app_pro_plugin_headerfacebook\";s:25:\"https://www.facebook.com/\";s:39:\"vw_mobile_app_pro_plugin_headerlinkedin\";s:24:\"https://www.linkedin.com\";s:41:\"vw_mobile_app_pro_plugin_headergoogleplus\";s:24:\"https://plus.google.com/\";s:38:\"vw_mobile_app_pro_plugin_headeryoutube\";s:24:\"https://www.youtube.com/\";s:40:\"vw_mobile_app_pro_plugin_headerpinterest\";s:25:\"https://in.pinterest.com/\";s:54:\"vw_mobile_app_pro_plugin_footer_contact_details_number\";s:1:\"3\";s:57:\"vw_mobile_app_pro_plugin_footer_contact_details_box_icon1\";s:21:\"fas fa-map-marker-alt\";s:52:\"vw_mobile_app_pro_plugin_footer_contact_details_box1\";s:41:\"351 Montreal Ave, Staten Island, NY 10306\";s:57:\"vw_mobile_app_pro_plugin_footer_contact_details_box_icon2\";s:12:\"fas fa-phone\";s:52:\"vw_mobile_app_pro_plugin_footer_contact_details_box2\";s:23:\"9876543210 , 1234567890\";s:57:\"vw_mobile_app_pro_plugin_footer_contact_details_box_icon3\";s:15:\"fas fa-envelope\";s:52:\"vw_mobile_app_pro_plugin_footer_contact_details_box3\";s:35:\"Expample@gmail.com, 12345@gmail.com\";s:36:\"vw_mobile_app_pro_plugin_footer_logo\";s:101:\"http://localhost/poultry-web/wp-content/plugins/vw-mobile-app-pro-plugin/assets/images/footerlogo.png\";s:42:\"vw_mobile_app_pro_plugin_address_longitude\";s:10:\"-80.053361\";s:41:\"vw_mobile_app_pro_plugin_address_latitude\";s:9:\"26.704241\";s:48:\"vw_mobile_app_pro_plugin_contactpage_email_title\";s:6:\"Email \";s:42:\"vw_mobile_app_pro_plugin_contactpage_email\";s:24:\"joyspoultryapp@gmail.com\";s:38:\"vw_mobile_app_pro_plugin_address_title\";s:7:\"Address\";s:32:\"vw_mobile_app_pro_plugin_address\";s:19:\"Piravom, Pin 686664\";s:48:\"vw_mobile_app_pro_plugin_contactpage_phone_title\";s:5:\"Phone\";s:42:\"vw_mobile_app_pro_plugin_contactpage_phone\";s:13:\"+918457146508\";s:56:\"vw_mobile_app_pro_plugin_contactpage_working_hours_title\";s:13:\"Working Hours\";s:50:\"vw_mobile_app_pro_plugin_contactpage_working_hours\";s:25:\"Monday-Friday, 8am to 6pm\";s:46:\"vw_mobile_app_pro_plugin_contactpage_form_desc\";s:447:\"Te obtinuit ut adepto satis somno. Aliisque institoribus iter deliciae vivet vita. Nam exempli gratia, quotiens ego vadam ad diversorum peregrinorum.Te obtinuit ut adepto satis somno. Aliisque institoribus iter deliciae vivet vita. Nam exempli gratia, quotiens ego vadam ad diversorum peregrinorum.Te obtinuit ut adepto satis somno. Aliisque institoribus iter deliciae vivet vita. Nam exempli gratia, quotiens ego vadam ad diversorum peregrinorum.\";s:47:\"vw_mobile_app_pro_plugin_contactpage_form_title\";s:10:\"SAY HELLO!\";s:50:\"vw_mobile_app_pro_plugin_contactpage_form_subtitle\";s:31:\"We would love to hear from you!\";s:36:\"vw_mobile_app_pro_plugin_footer_copy\";s:42:\"Powered by Bharatham IT Solutions PVT.LTD.\";s:34:\"vw_mobile_app_pro_plugin_shortcode\";s:72:\"[vw-mobile-app-pro-plugin-team], [vw-mobile-app-pro-plugin-testimonials]\";s:40:\"vw_mobile_app_pro_plugin_records_bgimage\";s:0:\"\";s:39:\"vw_mobile_app_pro_plugin_hi_third_color\";s:7:\"#128bcf\";s:42:\"vw_mobile_app_pro_plugin_radio_post_enable\";s:7:\"Disable\";s:48:\"vw_mobile_app_pro_plugin_radio_boxed_full_layout\";s:10:\"full-Width\";s:45:\"vw_mobile_app_pro_plugin_plans_pricing_enable\";s:6:\"Enable\";s:48:\"vw_mobile_app_pro_plugin_plans_price_one_bgcolor\";s:7:\"#128bcf\";s:48:\"vw_mobile_app_pro_plugin_plans_price_two_bgcolor\";s:7:\"#41c69a\";}', 'yes'),
(152, 'theme_switched', '', 'yes'),
(153, 'widget_sirat_social_widget', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(154, 'widget_sirat_about_widget', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(155, 'widget_sirat_contact_widget', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(156, 'recently_activated', 'a:0:{}', 'yes'),
(162, 'theme_mods_twentynineteen', 'a:3:{i:0;b:0;s:18:\"nav_menu_locations\";a:0:{}s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1628835445;s:4:\"data\";a:2:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:5:{i:0;s:7:\"block-2\";i:1;s:7:\"block-3\";i:2;s:7:\"block-4\";i:3;s:7:\"block-5\";i:4;s:7:\"block-6\";}}}}', 'yes'),
(166, 'widget_wpb_widget', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(167, 'widget_wpb_social_widget', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(168, 'vw_mobile_app_pro_plugin_r_review', 'a:2:{s:4:\"time\";i:1628835437;s:9:\"dismissed\";b:0;}', 'yes'),
(173, 'widget_recent-comments', 'a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}', 'yes'),
(174, 'widget_recent-posts', 'a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}', 'yes'),
(192, 'bsr_data', 'a:8:{s:13:\"select_tables\";a:12:{i:0;s:14:\"pd_commentmeta\";i:1;s:11:\"pd_comments\";i:2;s:8:\"pd_links\";i:3;s:10:\"pd_options\";i:4;s:11:\"pd_postmeta\";i:5;s:8:\"pd_posts\";i:6;s:21:\"pd_term_relationships\";i:7;s:16:\"pd_term_taxonomy\";i:8;s:11:\"pd_termmeta\";i:9;s:8:\"pd_terms\";i:10;s:11:\"pd_usermeta\";i:11;s:8:\"pd_users\";}s:16:\"case_insensitive\";s:3:\"off\";s:13:\"replace_guids\";s:2:\"on\";s:7:\"dry_run\";s:3:\"off\";s:10:\"search_for\";s:39:\"http://localhost/poultry-web/wordpress/\";s:12:\"replace_with\";s:29:\"http://localhost/poultry-web/\";s:15:\"completed_pages\";i:12;s:11:\"total_pages\";i:12;}', 'yes'),
(203, '_transient_health-check-site-status-result', '{\"good\":12,\"recommended\":7,\"critical\":0}', 'yes'),
(317, '_site_transient_timeout_theme_roots', '1630558425', 'no'),
(318, '_site_transient_theme_roots', 'a:4:{s:5:\"sirat\";s:7:\"/themes\";s:14:\"twentynineteen\";s:7:\"/themes\";s:12:\"twentytwenty\";s:7:\"/themes\";s:15:\"twentytwentyone\";s:7:\"/themes\";}', 'no');
INSERT INTO `pd_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(319, '_site_transient_update_plugins', 'O:8:\"stdClass\":5:{s:12:\"last_checked\";i:1630556628;s:8:\"response\";a:1:{s:19:\"akismet/akismet.php\";O:8:\"stdClass\":12:{s:2:\"id\";s:21:\"w.org/plugins/akismet\";s:4:\"slug\";s:7:\"akismet\";s:6:\"plugin\";s:19:\"akismet/akismet.php\";s:11:\"new_version\";s:6:\"4.1.11\";s:3:\"url\";s:38:\"https://wordpress.org/plugins/akismet/\";s:7:\"package\";s:57:\"https://downloads.wordpress.org/plugin/akismet.4.1.11.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:59:\"https://ps.w.org/akismet/assets/icon-256x256.png?rev=969272\";s:2:\"1x\";s:59:\"https://ps.w.org/akismet/assets/icon-128x128.png?rev=969272\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:61:\"https://ps.w.org/akismet/assets/banner-772x250.jpg?rev=479904\";}s:11:\"banners_rtl\";a:0:{}s:8:\"requires\";s:3:\"4.6\";s:6:\"tested\";s:3:\"5.8\";s:12:\"requires_php\";b:0;}}s:12:\"translations\";a:0:{}s:9:\"no_update\";a:3:{s:47:\"better-search-replace/better-search-replace.php\";O:8:\"stdClass\":10:{s:2:\"id\";s:35:\"w.org/plugins/better-search-replace\";s:4:\"slug\";s:21:\"better-search-replace\";s:6:\"plugin\";s:47:\"better-search-replace/better-search-replace.php\";s:11:\"new_version\";s:5:\"1.3.4\";s:3:\"url\";s:52:\"https://wordpress.org/plugins/better-search-replace/\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/plugin/better-search-replace.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:74:\"https://ps.w.org/better-search-replace/assets/icon-256x256.png?rev=1238934\";s:2:\"1x\";s:74:\"https://ps.w.org/better-search-replace/assets/icon-128x128.png?rev=1238934\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:77:\"https://ps.w.org/better-search-replace/assets/banner-1544x500.png?rev=1238934\";s:2:\"1x\";s:76:\"https://ps.w.org/better-search-replace/assets/banner-772x250.png?rev=1238934\";}s:11:\"banners_rtl\";a:0:{}s:8:\"requires\";s:5:\"3.0.1\";}s:9:\"hello.php\";O:8:\"stdClass\":10:{s:2:\"id\";s:25:\"w.org/plugins/hello-dolly\";s:4:\"slug\";s:11:\"hello-dolly\";s:6:\"plugin\";s:9:\"hello.php\";s:11:\"new_version\";s:5:\"1.7.2\";s:3:\"url\";s:42:\"https://wordpress.org/plugins/hello-dolly/\";s:7:\"package\";s:60:\"https://downloads.wordpress.org/plugin/hello-dolly.1.7.2.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:64:\"https://ps.w.org/hello-dolly/assets/icon-256x256.jpg?rev=2052855\";s:2:\"1x\";s:64:\"https://ps.w.org/hello-dolly/assets/icon-128x128.jpg?rev=2052855\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:66:\"https://ps.w.org/hello-dolly/assets/banner-772x250.jpg?rev=2052855\";}s:11:\"banners_rtl\";a:0:{}s:8:\"requires\";s:3:\"4.6\";}s:47:\"show-current-template/show-current-template.php\";O:8:\"stdClass\":10:{s:2:\"id\";s:35:\"w.org/plugins/show-current-template\";s:4:\"slug\";s:21:\"show-current-template\";s:6:\"plugin\";s:47:\"show-current-template/show-current-template.php\";s:11:\"new_version\";s:5:\"0.4.6\";s:3:\"url\";s:52:\"https://wordpress.org/plugins/show-current-template/\";s:7:\"package\";s:70:\"https://downloads.wordpress.org/plugin/show-current-template.0.4.6.zip\";s:5:\"icons\";a:3:{s:2:\"2x\";s:73:\"https://ps.w.org/show-current-template/assets/icon-256x256.png?rev=976031\";s:2:\"1x\";s:65:\"https://ps.w.org/show-current-template/assets/icon.svg?rev=976031\";s:3:\"svg\";s:65:\"https://ps.w.org/show-current-template/assets/icon.svg?rev=976031\";}s:7:\"banners\";a:0:{}s:11:\"banners_rtl\";a:0:{}s:8:\"requires\";s:3:\"3.5\";}}s:7:\"checked\";a:5:{s:19:\"akismet/akismet.php\";s:6:\"4.1.10\";s:47:\"better-search-replace/better-search-replace.php\";s:5:\"1.3.4\";s:9:\"hello.php\";s:5:\"1.7.2\";s:47:\"show-current-template/show-current-template.php\";s:5:\"0.4.6\";s:34:\"vw-mobile-app-pro-plugin/index.php\";s:3:\"1.0\";}}', 'no');

-- --------------------------------------------------------

--
-- Table structure for table `pd_postmeta`
--

CREATE TABLE `pd_postmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL,
  `post_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pd_postmeta`
--

INSERT INTO `pd_postmeta` (`meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1, 2, '_wp_page_template', 'default'),
(2, 3, '_wp_page_template', 'default'),
(5, 6, 'vw_mobile_app_pro_plugin_posttype_team_featured', '0'),
(6, 6, '_wp_page_template', 'page-template/home-page.php'),
(7, 7, 'vw_mobile_app_pro_plugin_posttype_team_featured', '0'),
(8, 7, '_wp_page_template', 'page-template/blog-fullwidth-extend.php'),
(9, 8, 'vw_mobile_app_pro_plugin_posttype_team_featured', '0'),
(10, 9, 'vw_mobile_app_pro_plugin_posttype_team_featured', '0'),
(11, 10, 'vw_mobile_app_pro_plugin_posttype_team_featured', '0'),
(12, 11, 'vw_mobile_app_pro_plugin_posttype_team_featured', '0'),
(13, 11, '_wp_page_template', 'page-template/contact.php'),
(15, 12, 'vw_mobile_app_pro_plugin_posttype_team_featured', '0'),
(16, 13, '_wp_attached_file', '2021/08/news1.jpg'),
(17, 13, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:569;s:6:\"height\";i:321;s:4:\"file\";s:17:\"2021/08/news1.jpg\";s:5:\"sizes\";a:3:{s:6:\"medium\";a:4:{s:4:\"file\";s:17:\"news1-300x169.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:169;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:17:\"news1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:20:\"sirat-homepage-thumb\";a:4:{s:4:\"file\";s:17:\"news1-240x145.jpg\";s:5:\"width\";i:240;s:6:\"height\";i:145;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(18, 12, '_thumbnail_id', '13'),
(20, 14, 'vw_mobile_app_pro_plugin_posttype_team_featured', '0'),
(21, 15, '_wp_attached_file', '2021/08/news2.jpg'),
(22, 15, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:569;s:6:\"height\";i:321;s:4:\"file\";s:17:\"2021/08/news2.jpg\";s:5:\"sizes\";a:3:{s:6:\"medium\";a:4:{s:4:\"file\";s:17:\"news2-300x169.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:169;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:17:\"news2-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:20:\"sirat-homepage-thumb\";a:4:{s:4:\"file\";s:17:\"news2-240x145.jpg\";s:5:\"width\";i:240;s:6:\"height\";i:145;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(23, 14, '_thumbnail_id', '15'),
(24, 16, 'vw_mobile_app_pro_plugin_posttype_team_featured', '0'),
(25, 16, 'vw_mobile_app_pro_plugin_posttype_testimonial_desigstory', 'Developer, Apps craft'),
(26, 17, '_wp_attached_file', '2021/08/testimonial1.jpg'),
(27, 17, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:112;s:6:\"height\";i:112;s:4:\"file\";s:24:\"2021/08/testimonial1.jpg\";s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(28, 16, '_thumbnail_id', '17'),
(29, 18, 'vw_mobile_app_pro_plugin_posttype_team_featured', '0'),
(30, 18, 'vw_mobile_app_pro_plugin_posttype_testimonial_desigstory', 'Ux designer, Apps craft'),
(31, 19, '_wp_attached_file', '2021/08/testimonial2.jpg'),
(32, 19, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:112;s:6:\"height\";i:112;s:4:\"file\";s:24:\"2021/08/testimonial2.jpg\";s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(33, 18, '_thumbnail_id', '19'),
(34, 20, 'vw_mobile_app_pro_plugin_posttype_team_featured', '0'),
(35, 20, 'vw_mobile_app_pro_plugin_posttype_testimonial_desigstory', 'Developer, Apps craft'),
(36, 21, '_wp_attached_file', '2021/08/testimonial3.jpg'),
(37, 21, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:112;s:6:\"height\";i:112;s:4:\"file\";s:24:\"2021/08/testimonial3.jpg\";s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(38, 20, '_thumbnail_id', '21'),
(39, 22, 'vw_mobile_app_pro_plugin_posttype_team_featured', '0'),
(40, 22, 'meta-desig', 'team@gmail.com'),
(41, 22, 'meta-call', '123-456-789'),
(42, 22, 'meta-facebookurl', 'https://www.facebook.com/'),
(43, 22, 'meta-linkdenurl', 'https://www.linkedin.com'),
(44, 22, 'meta-twitterurl', 'https://twitter.com/'),
(45, 22, 'meta-googleplusurl', 'https://plus.google.com'),
(46, 22, 'meta-designation', '  Mobile UI/UX Developer'),
(47, 23, '_wp_attached_file', '2021/08/team1.jpg'),
(48, 23, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:270;s:6:\"height\";i:340;s:4:\"file\";s:17:\"2021/08/team1.jpg\";s:5:\"sizes\";a:3:{s:6:\"medium\";a:4:{s:4:\"file\";s:17:\"team1-238x300.jpg\";s:5:\"width\";i:238;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:17:\"team1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:20:\"sirat-homepage-thumb\";a:4:{s:4:\"file\";s:17:\"team1-240x145.jpg\";s:5:\"width\";i:240;s:6:\"height\";i:145;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(49, 22, '_thumbnail_id', '23'),
(50, 24, 'vw_mobile_app_pro_plugin_posttype_team_featured', '0'),
(51, 24, 'meta-desig', 'team@gmail.com'),
(52, 24, 'meta-call', '123-456-789'),
(53, 24, 'meta-facebookurl', 'https://www.facebook.com/'),
(54, 24, 'meta-linkdenurl', 'https://www.linkedin.com'),
(55, 24, 'meta-twitterurl', 'https://twitter.com/'),
(56, 24, 'meta-googleplusurl', 'https://plus.google.com'),
(57, 24, 'meta-designation', NULL),
(58, 25, '_wp_attached_file', '2021/08/team2.jpg'),
(59, 25, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:270;s:6:\"height\";i:340;s:4:\"file\";s:17:\"2021/08/team2.jpg\";s:5:\"sizes\";a:3:{s:6:\"medium\";a:4:{s:4:\"file\";s:17:\"team2-238x300.jpg\";s:5:\"width\";i:238;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:17:\"team2-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:20:\"sirat-homepage-thumb\";a:4:{s:4:\"file\";s:17:\"team2-240x145.jpg\";s:5:\"width\";i:240;s:6:\"height\";i:145;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(60, 24, '_thumbnail_id', '25'),
(61, 26, 'vw_mobile_app_pro_plugin_posttype_team_featured', '0'),
(62, 26, 'meta-desig', 'team@gmail.com'),
(63, 26, 'meta-call', '123-456-789'),
(64, 26, 'meta-facebookurl', 'https://www.facebook.com/'),
(65, 26, 'meta-linkdenurl', 'https://www.linkedin.com'),
(66, 26, 'meta-twitterurl', 'https://twitter.com/'),
(67, 26, 'meta-googleplusurl', 'https://plus.google.com'),
(68, 26, 'meta-designation', NULL),
(69, 27, '_wp_attached_file', '2021/08/team3.jpg'),
(70, 27, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:270;s:6:\"height\";i:340;s:4:\"file\";s:17:\"2021/08/team3.jpg\";s:5:\"sizes\";a:3:{s:6:\"medium\";a:4:{s:4:\"file\";s:17:\"team3-238x300.jpg\";s:5:\"width\";i:238;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:17:\"team3-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:20:\"sirat-homepage-thumb\";a:4:{s:4:\"file\";s:17:\"team3-240x145.jpg\";s:5:\"width\";i:240;s:6:\"height\";i:145;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(71, 26, '_thumbnail_id', '27'),
(72, 28, 'vw_mobile_app_pro_plugin_posttype_team_featured', '0'),
(73, 28, 'meta-desig', 'team@gmail.com'),
(74, 28, 'meta-call', '123-456-789'),
(75, 28, 'meta-facebookurl', 'https://www.facebook.com/'),
(76, 28, 'meta-linkdenurl', 'https://www.linkedin.com'),
(77, 28, 'meta-twitterurl', 'https://twitter.com/'),
(78, 28, 'meta-googleplusurl', 'https://plus.google.com'),
(79, 28, 'meta-designation', NULL),
(80, 29, '_wp_attached_file', '2021/08/team4.jpg'),
(81, 29, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:270;s:6:\"height\";i:340;s:4:\"file\";s:17:\"2021/08/team4.jpg\";s:5:\"sizes\";a:3:{s:6:\"medium\";a:4:{s:4:\"file\";s:17:\"team4-238x300.jpg\";s:5:\"width\";i:238;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:17:\"team4-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:20:\"sirat-homepage-thumb\";a:4:{s:4:\"file\";s:17:\"team4-240x145.jpg\";s:5:\"width\";i:240;s:6:\"height\";i:145;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(82, 28, '_thumbnail_id', '29'),
(83, 30, '_wp_attached_file', '2021/08/mobile-1.png'),
(84, 30, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:395;s:6:\"height\";i:619;s:4:\"file\";s:20:\"2021/08/mobile-1.png\";s:5:\"sizes\";a:3:{s:6:\"medium\";a:4:{s:4:\"file\";s:20:\"mobile-1-191x300.png\";s:5:\"width\";i:191;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:20:\"mobile-1-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:20:\"sirat-homepage-thumb\";a:4:{s:4:\"file\";s:20:\"mobile-1-240x145.png\";s:5:\"width\";i:240;s:6:\"height\";i:145;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(85, 31, 'vw_mobile_app_pro_plugin_posttype_team_featured', '0'),
(86, 31, '_edit_lock', '1628842577:1'),
(87, 32, '_wp_attached_file', '2021/08/Group-24.png'),
(88, 32, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:1356;s:6:\"height\";i:261;s:4:\"file\";s:20:\"2021/08/Group-24.png\";s:5:\"sizes\";a:5:{s:6:\"medium\";a:4:{s:4:\"file\";s:19:\"Group-24-300x58.png\";s:5:\"width\";i:300;s:6:\"height\";i:58;s:9:\"mime-type\";s:9:\"image/png\";}s:5:\"large\";a:4:{s:4:\"file\";s:21:\"Group-24-1024x197.png\";s:5:\"width\";i:1024;s:6:\"height\";i:197;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:20:\"Group-24-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:20:\"Group-24-768x148.png\";s:5:\"width\";i:768;s:6:\"height\";i:148;s:9:\"mime-type\";s:9:\"image/png\";}s:20:\"sirat-homepage-thumb\";a:4:{s:4:\"file\";s:20:\"Group-24-240x145.png\";s:5:\"width\";i:240;s:6:\"height\";i:145;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(89, 33, '_wp_attached_file', '2021/08/Group-25.png'),
(90, 33, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:1938;s:6:\"height\";i:1542;s:4:\"file\";s:20:\"2021/08/Group-25.png\";s:5:\"sizes\";a:6:{s:6:\"medium\";a:4:{s:4:\"file\";s:20:\"Group-25-300x239.png\";s:5:\"width\";i:300;s:6:\"height\";i:239;s:9:\"mime-type\";s:9:\"image/png\";}s:5:\"large\";a:4:{s:4:\"file\";s:21:\"Group-25-1024x815.png\";s:5:\"width\";i:1024;s:6:\"height\";i:815;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:20:\"Group-25-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:20:\"Group-25-768x611.png\";s:5:\"width\";i:768;s:6:\"height\";i:611;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"1536x1536\";a:4:{s:4:\"file\";s:22:\"Group-25-1536x1222.png\";s:5:\"width\";i:1536;s:6:\"height\";i:1222;s:9:\"mime-type\";s:9:\"image/png\";}s:20:\"sirat-homepage-thumb\";a:4:{s:4:\"file\";s:20:\"Group-25-240x145.png\";s:5:\"width\";i:240;s:6:\"height\";i:145;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(91, 31, '_wp_trash_meta_status', 'publish'),
(92, 31, '_wp_trash_meta_time', '1628842613'),
(93, 34, 'vw_mobile_app_pro_plugin_posttype_team_featured', '0'),
(94, 34, '_edit_lock', '1628843657:1'),
(95, 35, '_wp_attached_file', '2021/08/272-2723071_gr-icons-text-black-chicken-02-rooster.png'),
(96, 35, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:77;s:6:\"height\";i:98;s:4:\"file\";s:62:\"2021/08/272-2723071_gr-icons-text-black-chicken-02-rooster.png\";s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(97, 36, '_wp_attached_file', '2021/08/323-3236283_logistics-comments-supply-icon-png-clipart.png'),
(98, 36, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:83;s:6:\"height\";i:87;s:4:\"file\";s:66:\"2021/08/323-3236283_logistics-comments-supply-icon-png-clipart.png\";s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(99, 37, '_wp_attached_file', '2021/08/523-5230105_discount-shop-png-icon-sale-png-transparent-png.png'),
(100, 37, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:87;s:6:\"height\";i:107;s:4:\"file\";s:71:\"2021/08/523-5230105_discount-shop-png-icon-sale-png-transparent-png.png\";s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(101, 34, '_wp_trash_meta_status', 'publish'),
(102, 34, '_wp_trash_meta_time', '1628843684'),
(103, 38, 'vw_mobile_app_pro_plugin_posttype_team_featured', '0'),
(104, 38, '_edit_lock', '1628843831:1'),
(105, 39, '_wp_attached_file', '2021/08/indoors-chicken-farm-chicken-feeding.png'),
(106, 39, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:1922;s:6:\"height\";i:659;s:4:\"file\";s:48:\"2021/08/indoors-chicken-farm-chicken-feeding.png\";s:5:\"sizes\";a:6:{s:6:\"medium\";a:4:{s:4:\"file\";s:48:\"indoors-chicken-farm-chicken-feeding-300x103.png\";s:5:\"width\";i:300;s:6:\"height\";i:103;s:9:\"mime-type\";s:9:\"image/png\";}s:5:\"large\";a:4:{s:4:\"file\";s:49:\"indoors-chicken-farm-chicken-feeding-1024x351.png\";s:5:\"width\";i:1024;s:6:\"height\";i:351;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:48:\"indoors-chicken-farm-chicken-feeding-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:48:\"indoors-chicken-farm-chicken-feeding-768x263.png\";s:5:\"width\";i:768;s:6:\"height\";i:263;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"1536x1536\";a:4:{s:4:\"file\";s:49:\"indoors-chicken-farm-chicken-feeding-1536x527.png\";s:5:\"width\";i:1536;s:6:\"height\";i:527;s:9:\"mime-type\";s:9:\"image/png\";}s:20:\"sirat-homepage-thumb\";a:4:{s:4:\"file\";s:48:\"indoors-chicken-farm-chicken-feeding-240x145.png\";s:5:\"width\";i:240;s:6:\"height\";i:145;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(107, 38, '_wp_trash_meta_status', 'publish'),
(108, 38, '_wp_trash_meta_time', '1628843861'),
(109, 40, '_wp_trash_meta_status', 'publish'),
(110, 40, '_wp_trash_meta_time', '1628844029'),
(111, 40, 'vw_mobile_app_pro_plugin_posttype_team_featured', '0'),
(112, 41, 'vw_mobile_app_pro_plugin_posttype_team_featured', '0'),
(113, 41, '_edit_lock', '1628844340:1'),
(114, 41, '_wp_trash_meta_status', 'publish'),
(115, 41, '_wp_trash_meta_time', '1628844342'),
(116, 42, 'vw_mobile_app_pro_plugin_posttype_team_featured', '0'),
(117, 42, '_edit_lock', '1628844824:1'),
(118, 42, '_wp_trash_meta_status', 'publish'),
(119, 42, '_wp_trash_meta_time', '1628844826'),
(122, 44, '_wp_attached_file', '2021/08/02.jpg'),
(123, 44, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:500;s:6:\"height\";i:1024;s:4:\"file\";s:14:\"2021/08/02.jpg\";s:5:\"sizes\";a:3:{s:6:\"medium\";a:4:{s:4:\"file\";s:14:\"02-146x300.jpg\";s:5:\"width\";i:146;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:14:\"02-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:20:\"sirat-homepage-thumb\";a:4:{s:4:\"file\";s:14:\"02-240x145.jpg\";s:5:\"width\";i:240;s:6:\"height\";i:145;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}'),
(125, 45, 'vw_mobile_app_pro_plugin_posttype_team_featured', '0'),
(126, 45, '_edit_lock', '1628847739:1'),
(127, 46, '_wp_attached_file', '2021/08/Mask-Group-3.png'),
(128, 46, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:1971;s:6:\"height\";i:1163;s:4:\"file\";s:24:\"2021/08/Mask-Group-3.png\";s:5:\"sizes\";a:6:{s:6:\"medium\";a:4:{s:4:\"file\";s:24:\"Mask-Group-3-300x177.png\";s:5:\"width\";i:300;s:6:\"height\";i:177;s:9:\"mime-type\";s:9:\"image/png\";}s:5:\"large\";a:4:{s:4:\"file\";s:25:\"Mask-Group-3-1024x604.png\";s:5:\"width\";i:1024;s:6:\"height\";i:604;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:24:\"Mask-Group-3-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:24:\"Mask-Group-3-768x453.png\";s:5:\"width\";i:768;s:6:\"height\";i:453;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"1536x1536\";a:4:{s:4:\"file\";s:25:\"Mask-Group-3-1536x906.png\";s:5:\"width\";i:1536;s:6:\"height\";i:906;s:9:\"mime-type\";s:9:\"image/png\";}s:20:\"sirat-homepage-thumb\";a:4:{s:4:\"file\";s:24:\"Mask-Group-3-240x145.png\";s:5:\"width\";i:240;s:6:\"height\";i:145;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(129, 45, '_wp_trash_meta_status', 'publish'),
(130, 45, '_wp_trash_meta_time', '1628847783'),
(131, 47, 'vw_mobile_app_pro_plugin_posttype_team_featured', '0'),
(132, 47, '_edit_lock', '1628848052:1'),
(133, 47, '_wp_trash_meta_status', 'publish'),
(134, 47, '_wp_trash_meta_time', '1628848104'),
(135, 48, 'vw_mobile_app_pro_plugin_posttype_team_featured', '0'),
(136, 48, '_edit_lock', '1628848390:1'),
(137, 49, '_wp_attached_file', '2021/08/02-1.jpg'),
(138, 49, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:500;s:6:\"height\";i:1024;s:4:\"file\";s:16:\"2021/08/02-1.jpg\";s:5:\"sizes\";a:3:{s:6:\"medium\";a:4:{s:4:\"file\";s:16:\"02-1-146x300.jpg\";s:5:\"width\";i:146;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:16:\"02-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:20:\"sirat-homepage-thumb\";a:4:{s:4:\"file\";s:16:\"02-1-240x145.jpg\";s:5:\"width\";i:240;s:6:\"height\";i:145;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}'),
(139, 50, '_wp_attached_file', '2021/08/03.jpg'),
(140, 50, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:500;s:6:\"height\";i:1024;s:4:\"file\";s:14:\"2021/08/03.jpg\";s:5:\"sizes\";a:3:{s:6:\"medium\";a:4:{s:4:\"file\";s:14:\"03-146x300.jpg\";s:5:\"width\";i:146;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:14:\"03-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:20:\"sirat-homepage-thumb\";a:4:{s:4:\"file\";s:14:\"03-240x145.jpg\";s:5:\"width\";i:240;s:6:\"height\";i:145;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}'),
(141, 51, '_wp_attached_file', '2021/08/04.jpg'),
(142, 51, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:500;s:6:\"height\";i:1024;s:4:\"file\";s:14:\"2021/08/04.jpg\";s:5:\"sizes\";a:3:{s:6:\"medium\";a:4:{s:4:\"file\";s:14:\"04-146x300.jpg\";s:5:\"width\";i:146;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:14:\"04-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:20:\"sirat-homepage-thumb\";a:4:{s:4:\"file\";s:14:\"04-240x145.jpg\";s:5:\"width\";i:240;s:6:\"height\";i:145;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}'),
(143, 48, '_wp_trash_meta_status', 'publish'),
(144, 48, '_wp_trash_meta_time', '1628848398'),
(145, 52, '_wp_attached_file', '2021/08/001.png'),
(146, 52, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:500;s:6:\"height\";i:1024;s:4:\"file\";s:15:\"2021/08/001.png\";s:5:\"sizes\";a:3:{s:6:\"medium\";a:4:{s:4:\"file\";s:15:\"001-146x300.png\";s:5:\"width\";i:146;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:15:\"001-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:20:\"sirat-homepage-thumb\";a:4:{s:4:\"file\";s:15:\"001-240x145.png\";s:5:\"width\";i:240;s:6:\"height\";i:145;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(147, 53, 'vw_mobile_app_pro_plugin_posttype_team_featured', '0'),
(148, 53, '_edit_lock', '1628848944:1'),
(149, 54, '_wp_attached_file', '2021/08/002.png'),
(150, 54, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:500;s:6:\"height\";i:1024;s:4:\"file\";s:15:\"2021/08/002.png\";s:5:\"sizes\";a:3:{s:6:\"medium\";a:4:{s:4:\"file\";s:15:\"002-146x300.png\";s:5:\"width\";i:146;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:15:\"002-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:20:\"sirat-homepage-thumb\";a:4:{s:4:\"file\";s:15:\"002-240x145.png\";s:5:\"width\";i:240;s:6:\"height\";i:145;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(151, 55, '_wp_attached_file', '2021/08/003.png'),
(152, 55, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:500;s:6:\"height\";i:1024;s:4:\"file\";s:15:\"2021/08/003.png\";s:5:\"sizes\";a:3:{s:6:\"medium\";a:4:{s:4:\"file\";s:15:\"003-146x300.png\";s:5:\"width\";i:146;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:15:\"003-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:20:\"sirat-homepage-thumb\";a:4:{s:4:\"file\";s:15:\"003-240x145.png\";s:5:\"width\";i:240;s:6:\"height\";i:145;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(153, 56, '_wp_attached_file', '2021/08/004.png'),
(154, 56, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:500;s:6:\"height\";i:1024;s:4:\"file\";s:15:\"2021/08/004.png\";s:5:\"sizes\";a:3:{s:6:\"medium\";a:4:{s:4:\"file\";s:15:\"004-146x300.png\";s:5:\"width\";i:146;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:15:\"004-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:20:\"sirat-homepage-thumb\";a:4:{s:4:\"file\";s:15:\"004-240x145.png\";s:5:\"width\";i:240;s:6:\"height\";i:145;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(155, 57, '_wp_attached_file', '2021/08/amezingfeaturesimg-1.png'),
(156, 57, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:271;s:6:\"height\";i:541;s:4:\"file\";s:32:\"2021/08/amezingfeaturesimg-1.png\";s:5:\"sizes\";a:3:{s:6:\"medium\";a:4:{s:4:\"file\";s:32:\"amezingfeaturesimg-1-150x300.png\";s:5:\"width\";i:150;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:32:\"amezingfeaturesimg-1-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:20:\"sirat-homepage-thumb\";a:4:{s:4:\"file\";s:32:\"amezingfeaturesimg-1-240x145.png\";s:5:\"width\";i:240;s:6:\"height\";i:145;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(157, 53, '_wp_trash_meta_status', 'publish'),
(158, 53, '_wp_trash_meta_time', '1628848946'),
(160, 59, 'vw_mobile_app_pro_plugin_posttype_team_featured', '0'),
(161, 59, '_edit_lock', '1628854004:1'),
(162, 59, '_wp_trash_meta_status', 'publish'),
(163, 59, '_wp_trash_meta_time', '1628854020'),
(164, 60, '_wp_attached_file', '2021/08/005.png'),
(165, 60, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:500;s:6:\"height\";i:1024;s:4:\"file\";s:15:\"2021/08/005.png\";s:5:\"sizes\";a:3:{s:6:\"medium\";a:4:{s:4:\"file\";s:15:\"005-146x300.png\";s:5:\"width\";i:146;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:15:\"005-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:20:\"sirat-homepage-thumb\";a:4:{s:4:\"file\";s:15:\"005-240x145.png\";s:5:\"width\";i:240;s:6:\"height\";i:145;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(166, 61, '_wp_trash_meta_status', 'publish'),
(167, 61, '_wp_trash_meta_time', '1628854376'),
(168, 61, 'vw_mobile_app_pro_plugin_posttype_team_featured', '0'),
(169, 62, 'vw_mobile_app_pro_plugin_posttype_team_featured', '0'),
(170, 62, '_edit_lock', '1628857248:1'),
(171, 62, '_wp_trash_meta_status', 'publish'),
(172, 62, '_wp_trash_meta_time', '1628857300'),
(173, 63, 'vw_mobile_app_pro_plugin_posttype_team_featured', '0'),
(174, 63, '_edit_lock', '1628858091:1'),
(175, 63, '_wp_trash_meta_status', 'publish'),
(176, 63, '_wp_trash_meta_time', '1628858100'),
(177, 64, '_wp_trash_meta_status', 'publish'),
(178, 64, '_wp_trash_meta_time', '1628858297'),
(179, 64, 'vw_mobile_app_pro_plugin_posttype_team_featured', '0'),
(180, 65, 'vw_mobile_app_pro_plugin_posttype_team_featured', '0'),
(181, 65, '_edit_lock', '1628915347:1'),
(182, 65, '_wp_trash_meta_status', 'publish'),
(183, 65, '_wp_trash_meta_time', '1628915351'),
(184, 66, 'vw_mobile_app_pro_plugin_posttype_team_featured', '0'),
(185, 66, '_edit_lock', '1628931672:1'),
(186, 66, '_wp_trash_meta_status', 'publish'),
(187, 66, '_wp_trash_meta_time', '1628931633'),
(188, 67, 'vw_mobile_app_pro_plugin_posttype_team_featured', '0'),
(189, 67, '_edit_lock', '1628932260:1'),
(190, 67, '_wp_trash_meta_status', 'publish'),
(191, 67, '_wp_trash_meta_time', '1628932297'),
(192, 68, 'vw_mobile_app_pro_plugin_posttype_team_featured', '0'),
(193, 68, '_edit_lock', '1628942576:1'),
(194, 68, '_wp_trash_meta_status', 'publish'),
(195, 68, '_wp_trash_meta_time', '1628942606'),
(196, 69, 'vw_mobile_app_pro_plugin_posttype_team_featured', '0'),
(197, 69, '_edit_lock', '1629891167:1'),
(198, 69, '_wp_trash_meta_status', 'publish'),
(199, 69, '_wp_trash_meta_time', '1629891184'),
(201, 6, '_edit_lock', '1629953452:1'),
(202, 71, '_wp_trash_meta_status', 'publish'),
(203, 71, '_wp_trash_meta_time', '1629962567'),
(204, 71, 'vw_mobile_app_pro_plugin_posttype_team_featured', '0');

-- --------------------------------------------------------

--
-- Table structure for table `pd_posts`
--

CREATE TABLE `pd_posts` (
  `ID` bigint(20) UNSIGNED NOT NULL,
  `post_author` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_parent` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `guid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT 0,
  `post_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pd_posts`
--

INSERT INTO `pd_posts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(1, 1, '2021-08-13 05:58:54', '2021-08-13 05:58:54', '<!-- wp:paragraph -->\n<p>Welcome to WordPress. This is your first post. Edit or delete it, then start writing!</p>\n<!-- /wp:paragraph -->', 'Hello world!', '', 'publish', 'open', 'open', '', 'hello-world', '', '', '2021-08-13 05:58:54', '2021-08-13 05:58:54', '', 0, 'http://localhost/poultry-web/?p=1', 0, 'post', '', 1),
(2, 1, '2021-08-13 05:58:54', '2021-08-13 05:58:54', '<!-- wp:paragraph -->\n<p>This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\"><p>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin\' caught in the rain.)</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>...or something like this:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\"><p>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>As a new WordPress user, you should go to <a href=\"http://localhost/poultry-web/wp-admin/\">your dashboard</a> to delete this page and create new pages for your content. Have fun!</p>\n<!-- /wp:paragraph -->', 'Sample Page', '', 'publish', 'closed', 'open', '', 'sample-page', '', '', '2021-08-13 05:58:54', '2021-08-13 05:58:54', '', 0, 'http://localhost/poultry-web/?page_id=2', 0, 'page', '', 0),
(3, 1, '2021-08-13 05:58:54', '2021-08-13 05:58:54', '<!-- wp:heading --><h2>Who we are</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>Our website address is: http://localhost/poultry-web/wordpress.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Comments</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>When visitors leave comments on the site we collect the data shown in the comments form, and also the visitor&#8217;s IP address and browser user agent string to help spam detection.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>An anonymized string created from your email address (also called a hash) may be provided to the Gravatar service to see if you are using it. The Gravatar service privacy policy is available here: https://automattic.com/privacy/. After approval of your comment, your profile picture is visible to the public in the context of your comment.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Media</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>If you upload images to the website, you should avoid uploading images with embedded location data (EXIF GPS) included. Visitors to the website can download and extract any location data from images on the website.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Cookies</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>If you leave a comment on our site you may opt-in to saving your name, email address and website in cookies. These are for your convenience so that you do not have to fill in your details again when you leave another comment. These cookies will last for one year.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>If you visit our login page, we will set a temporary cookie to determine if your browser accepts cookies. This cookie contains no personal data and is discarded when you close your browser.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>When you log in, we will also set up several cookies to save your login information and your screen display choices. Login cookies last for two days, and screen options cookies last for a year. If you select &quot;Remember Me&quot;, your login will persist for two weeks. If you log out of your account, the login cookies will be removed.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>If you edit or publish an article, an additional cookie will be saved in your browser. This cookie includes no personal data and simply indicates the post ID of the article you just edited. It expires after 1 day.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Embedded content from other websites</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>Articles on this site may include embedded content (e.g. videos, images, articles, etc.). Embedded content from other websites behaves in the exact same way as if the visitor has visited the other website.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>These websites may collect data about you, use cookies, embed additional third-party tracking, and monitor your interaction with that embedded content, including tracking your interaction with the embedded content if you have an account and are logged in to that website.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Who we share your data with</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>If you request a password reset, your IP address will be included in the reset email.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>How long we retain your data</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>If you leave a comment, the comment and its metadata are retained indefinitely. This is so we can recognize and approve any follow-up comments automatically instead of holding them in a moderation queue.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>For users that register on our website (if any), we also store the personal information they provide in their user profile. All users can see, edit, or delete their personal information at any time (except they cannot change their username). Website administrators can also see and edit that information.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>What rights you have over your data</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>If you have an account on this site, or have left comments, you can request to receive an exported file of the personal data we hold about you, including any data you have provided to us. You can also request that we erase any personal data we hold about you. This does not include any data we are obliged to keep for administrative, legal, or security purposes.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Where we send your data</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>Visitor comments may be checked through an automated spam detection service.</p><!-- /wp:paragraph -->', 'Privacy Policy', '', 'draft', 'closed', 'open', '', 'privacy-policy', '', '', '2021-08-13 05:58:54', '2021-08-13 05:58:54', '', 0, 'http://localhost/poultry-web/?page_id=3', 0, 'page', '', 0),
(6, 1, '2021-08-13 06:17:58', '2021-08-13 06:17:58', '', 'Home', '', 'publish', 'closed', 'closed', '', 'home', '', '', '2021-08-13 06:17:58', '2021-08-13 06:17:58', '', 0, 'http://localhost/poultry-web/home/', 0, 'page', '', 0),
(7, 1, '2021-08-13 06:17:59', '2021-08-13 06:17:59', '', 'Blog', '', 'publish', 'closed', 'closed', '', 'blog', '', '', '2021-08-13 06:17:59', '2021-08-13 06:17:59', '', 0, 'http://localhost/poultry-web/blog/', 0, 'page', '', 0),
(8, 1, '2021-08-13 06:17:59', '2021-08-13 06:17:59', '[vw-mobile-app-pro-plugin-testimonials]', 'Testimonials', '', 'publish', 'closed', 'closed', '', 'testimonials', '', '', '2021-08-13 06:17:59', '2021-08-13 06:17:59', '', 0, 'http://localhost/poultry-web/testimonials/', 0, 'page', '', 0),
(9, 1, '2021-08-13 06:17:59', '2021-08-13 06:17:59', '[vw-mobile-app-pro-plugin-team]', 'Team', '', 'publish', 'closed', 'closed', '', 'team', '', '', '2021-08-13 06:17:59', '2021-08-13 06:17:59', '', 0, 'http://localhost/poultry-web/team/', 0, 'page', '', 0),
(10, 1, '2021-08-13 06:18:00', '2021-08-13 06:18:00', 'Te obtinuit ut adepto satis somno. Aliisque institoribus iter deliciae vivet vita. Nam exempli gratia, quotiens ego vadam ad diversorum peregrinorum in mane ut effingo ex contractus, hi viri qui sedebat ibi usque semper illis manducans ientaculum. Solum cum bulla ut debui; EGO youd adepto a macula proiciendi. Sed quis scit si forte quod esset optima res pro me. sicut ea quae sentio. Qui vellem cadunt off ius desk ejus! Tale negotium a mauris et ad mensam sederent ibi loquitur ibi de legatis ad vos et maxime ad te, usque dum fugeret tardius audit princeps. Bene tamen fiduciam Ego got off semel, et argentum simul reddere parentibus meis, debitum eo aliam putant quinque aut sex annos.', 'Page', '', 'publish', 'closed', 'closed', '', 'page', '', '', '2021-08-13 06:18:00', '2021-08-13 06:18:00', '', 0, 'http://localhost/poultry-web/page/', 0, 'page', '', 0),
(11, 1, '2021-08-13 06:18:00', '2021-08-13 06:18:00', '', 'Contact', '', 'publish', 'closed', 'closed', '', 'contact', '', '', '2021-08-13 06:18:00', '2021-08-13 06:18:00', '', 0, 'http://localhost/poultry-web/contact/', 0, 'page', '', 0),
(12, 1, '2021-08-13 06:18:09', '2021-08-13 06:18:09', 'Te obtinuit ut adepto satis somno. Aliisque institoribus iter deliciae vivet vita. Nam exempli gratia, quotiens ego vadam ad diversorum peregrinorum.Te obtinuit ut adepto satis somno. Aliisque institoribus iter deliciae vivet vita. Nam exempli gratia, quotiens ego vadam ad diversorum peregrinorum.Te obtinuit ut adepto satis somno. Aliisque institoribus iter deliciae vivet vita. Nam exempli gratia, quotiens ego vadam ad diversorum peregrinorum.', 'BEAUTIFUL PLACE FOR YOUR GREAT JOURNEY', '', 'publish', 'open', 'open', '', 'beautiful-place-for-your-great-journey', '', '', '2021-08-13 06:18:09', '2021-08-13 06:18:09', '', 0, 'http://localhost/poultry-web/2021/08/13/beautiful-place-for-your-great-journey/', 0, 'post', '', 0),
(13, 1, '2021-08-13 06:18:10', '2021-08-13 06:18:10', '', 'news1.jpg', '', 'inherit', 'open', 'closed', '', 'news1-jpg', '', '', '2021-08-13 06:18:10', '2021-08-13 06:18:10', '', 12, 'http://localhost/poultry-web/2021/08/13/beautiful-place-for-your-great-journey/news1-jpg/', 0, 'attachment', 'image/jpeg', 0),
(14, 1, '2021-08-13 06:18:11', '2021-08-13 06:18:11', 'Te obtinuit ut adepto satis somno. Aliisque institoribus iter deliciae vivet vita. Nam exempli gratia, quotiens ego vadam ad diversorum peregrinorum.Te obtinuit ut adepto satis somno. Aliisque institoribus iter deliciae vivet vita. Nam exempli gratia, quotiens ego vadam ad diversorum peregrinorum.Te obtinuit ut adepto satis somno. Aliisque institoribus iter deliciae vivet vita. Nam exempli gratia, quotiens ego vadam ad diversorum peregrinorum.', 'BEST WAY TO LAUNCH AN SHARE YOUR APP', '', 'publish', 'open', 'open', '', 'best-way-to-launch-an-share-your-app', '', '', '2021-08-13 06:18:11', '2021-08-13 06:18:11', '', 0, 'http://localhost/poultry-web/2021/08/13/best-way-to-launch-an-share-your-app/', 0, 'post', '', 0),
(15, 1, '2021-08-13 06:18:12', '2021-08-13 06:18:12', '', 'news2.jpg', '', 'inherit', 'open', 'closed', '', 'news2-jpg', '', '', '2021-08-13 06:18:12', '2021-08-13 06:18:12', '', 14, 'http://localhost/poultry-web/2021/08/13/best-way-to-launch-an-share-your-app/news2-jpg/', 0, 'attachment', 'image/jpeg', 0),
(16, 1, '2021-08-13 06:18:13', '2021-08-13 06:18:13', 'Te obtinuit ut adepto satis somno. Aliisque institoribus iter deliciae vivet vita. Nam exempli gratia, quotiens ego vadam ad diversorum peregrinorum.Te obtinuit ut adepto satis somno. Aliisque institoribus iter deliciae vivet vita. Nam exempli gratia, quotiens ego vadam ad diversorum peregrinorum.Te obtinuit ut adepto satis somno. Aliisque institoribus iter deliciae vivet vita.', 'JHON CENA', '', 'publish', 'closed', 'closed', '', 'jhon-cena', '', '', '2021-08-13 06:18:13', '2021-08-13 06:18:13', '', 0, 'http://localhost/poultry-web/testimonials/jhon-cena/', 0, 'testimonials', '', 0),
(17, 1, '2021-08-13 06:18:14', '2021-08-13 06:18:14', '', 'testimonial1.jpg', '', 'inherit', 'open', 'closed', '', 'testimonial1-jpg', '', '', '2021-08-13 06:18:14', '2021-08-13 06:18:14', '', 16, 'http://localhost/poultry-web/testimonials/jhon-cena/testimonial1-jpg/', 0, 'attachment', 'image/jpeg', 0),
(18, 1, '2021-08-13 06:18:14', '2021-08-13 06:18:14', 'Te obtinuit ut adepto satis somno. Aliisque institoribus iter deliciae vivet vita. Nam exempli gratia, quotiens ego vadam ad diversorum peregrinorum.Te obtinuit ut adepto satis somno. Aliisque institoribus iter deliciae vivet vita. Nam exempli gratia, quotiens ego vadam ad diversorum peregrinorum.Te obtinuit ut adepto satis somno. Aliisque institoribus iter deliciae vivet vita.', 'KATTY PERRY', '', 'publish', 'closed', 'closed', '', 'katty-perry', '', '', '2021-08-13 06:18:14', '2021-08-13 06:18:14', '', 0, 'http://localhost/poultry-web/testimonials/katty-perry/', 0, 'testimonials', '', 0),
(19, 1, '2021-08-13 06:18:14', '2021-08-13 06:18:14', '', 'testimonial2.jpg', '', 'inherit', 'open', 'closed', '', 'testimonial2-jpg', '', '', '2021-08-13 06:18:14', '2021-08-13 06:18:14', '', 18, 'http://localhost/poultry-web/testimonials/katty-perry/testimonial2-jpg/', 0, 'attachment', 'image/jpeg', 0),
(20, 1, '2021-08-13 06:18:15', '2021-08-13 06:18:15', 'Te obtinuit ut adepto satis somno. Aliisque institoribus iter deliciae vivet vita. Nam exempli gratia, quotiens ego vadam ad diversorum peregrinorum.Te obtinuit ut adepto satis somno. Aliisque institoribus iter deliciae vivet vita. Nam exempli gratia, quotiens ego vadam ad diversorum peregrinorum.Te obtinuit ut adepto satis somno. Aliisque institoribus iter deliciae vivet vita.', 'JHON CENA', '', 'publish', 'closed', 'closed', '', 'jhon-cena-2', '', '', '2021-08-13 06:18:15', '2021-08-13 06:18:15', '', 0, 'http://localhost/poultry-web/testimonials/jhon-cena-2/', 0, 'testimonials', '', 0),
(21, 1, '2021-08-13 06:18:15', '2021-08-13 06:18:15', '', 'testimonial3.jpg', '', 'inherit', 'open', 'closed', '', 'testimonial3-jpg', '', '', '2021-08-13 06:18:15', '2021-08-13 06:18:15', '', 20, 'http://localhost/poultry-web/testimonials/jhon-cena-2/testimonial3-jpg/', 0, 'attachment', 'image/jpeg', 0),
(22, 1, '2021-08-13 06:18:15', '2021-08-13 06:18:15', 'Te obtinuit ut adepto satis somno. Aliisque institoribus iter deliciae vivet vita. Nam exempli gratia, quotiens ego vadam ad diversorum peregrinorum.Te obtinuit ut adepto satis somno. Aliisque institoribus iter deliciae vivet vita. Nam exempli gratia, quotiens ego vadam ad diversorum peregrinorum.Te obtinuit ut adepto satis somno. Aliisque institoribus iter deliciae vivet vita.', 'Sukuna chiken', '', 'publish', 'closed', 'closed', '', 'jason-statham', '', '', '2021-08-13 06:18:15', '2021-08-13 06:18:15', '', 0, 'http://localhost/poultry-web/team/jason-statham/', 0, 'team', '', 0),
(23, 1, '2021-08-13 06:18:16', '2021-08-13 06:18:16', '', 'team1.jpg', '', 'inherit', 'open', 'closed', '', 'team1-jpg', '', '', '2021-08-13 06:18:16', '2021-08-13 06:18:16', '', 22, 'http://localhost/poultry-web/team/jason-statham/team1-jpg/', 0, 'attachment', 'image/jpeg', 0),
(24, 1, '2021-08-13 06:18:17', '2021-08-13 06:18:17', 'Te obtinuit ut adepto satis somno. Aliisque institoribus iter deliciae vivet vita. Nam exempli gratia, quotiens ego vadam ad diversorum peregrinorum.Te obtinuit ut adepto satis somno. Aliisque institoribus iter deliciae vivet vita. Nam exempli gratia, quotiens ego vadam ad diversorum peregrinorum.Te obtinuit ut adepto satis somno. Aliisque institoribus iter deliciae vivet vita.', 'COBB 430', '', 'publish', 'closed', 'closed', '', 'jessica-graham', '', '', '2021-08-13 06:18:17', '2021-08-13 06:18:17', '', 0, 'http://localhost/poultry-web/team/jessica-graham/', 0, 'team', '', 0),
(25, 1, '2021-08-13 06:18:17', '2021-08-13 06:18:17', '', 'team2.jpg', '', 'inherit', 'open', 'closed', '', 'team2-jpg', '', '', '2021-08-13 06:18:17', '2021-08-13 06:18:17', '', 24, 'http://localhost/poultry-web/team/jessica-graham/team2-jpg/', 0, 'attachment', 'image/jpeg', 0),
(26, 1, '2021-08-13 06:18:18', '2021-08-13 06:18:18', 'Te obtinuit ut adepto satis somno. Aliisque institoribus iter deliciae vivet vita. Nam exempli gratia, quotiens ego vadam ad diversorum peregrinorum.Te obtinuit ut adepto satis somno. Aliisque institoribus iter deliciae vivet vita. Nam exempli gratia, quotiens ego vadam ad diversorum peregrinorum.Te obtinuit ut adepto satis somno. Aliisque institoribus iter deliciae vivet vita.', 'Krishi chiken', '', 'publish', 'closed', 'closed', '', 'jackie-bauer', '', '', '2021-08-13 06:18:18', '2021-08-13 06:18:18', '', 0, 'http://localhost/poultry-web/team/jackie-bauer/', 0, 'team', '', 0),
(27, 1, '2021-08-13 06:18:19', '2021-08-13 06:18:19', '', 'team3.jpg', '', 'inherit', 'open', 'closed', '', 'team3-jpg', '', '', '2021-08-13 06:18:19', '2021-08-13 06:18:19', '', 26, 'http://localhost/poultry-web/team/jackie-bauer/team3-jpg/', 0, 'attachment', 'image/jpeg', 0),
(28, 1, '2021-08-13 06:18:19', '2021-08-13 06:18:19', 'Te obtinuit ut adepto satis somno. Aliisque institoribus iter deliciae vivet vita. Nam exempli gratia, quotiens ego vadam ad diversorum peregrinorum.Te obtinuit ut adepto satis somno. Aliisque institoribus iter deliciae vivet vita. Nam exempli gratia, quotiens ego vadam ad diversorum peregrinorum.Te obtinuit ut adepto satis somno. Aliisque institoribus iter deliciae vivet vita.', 'Gramasree', '', 'publish', 'closed', 'closed', '', 'yasmin-pearson', '', '', '2021-08-13 06:18:19', '2021-08-13 06:18:19', '', 0, 'http://localhost/poultry-web/team/yasmin-pearson/', 0, 'team', '', 0),
(29, 1, '2021-08-13 06:18:20', '2021-08-13 06:18:20', '', 'team4.jpg', '', 'inherit', 'open', 'closed', '', 'team4-jpg', '', '', '2021-08-13 06:18:20', '2021-08-13 06:18:20', '', 28, 'http://localhost/poultry-web/team/yasmin-pearson/team4-jpg/', 0, 'attachment', 'image/jpeg', 0),
(30, 1, '2021-08-13 08:14:26', '2021-08-13 08:14:26', '', 'mobile (1)', '', 'inherit', 'open', 'closed', '', 'mobile-1', '', '', '2021-08-13 08:14:26', '2021-08-13 08:14:26', '', 0, 'http://localhost/poultry-web/wp-content/uploads/2021/08/mobile-1.png', 0, 'attachment', 'image/png', 0),
(31, 1, '2021-08-13 08:16:52', '2021-08-13 08:16:52', '{\n    \"sirat::vw_mobile_app_pro_plugin_main_banner_rightimage\": {\n        \"value\": \"http://localhost/poultry-web/wp-content/uploads/2021/08/mobile-1.png\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-08-13 08:15:09\"\n    },\n    \"sirat::vw_mobile_app_pro_plugin_promo_banner_bgimage_inner\": {\n        \"value\": \"http://localhost/poultry-web/wp-content/uploads/2021/08/Group-24.png\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-08-13 08:16:16\"\n    },\n    \"sirat::vw_mobile_app_pro_plugin_amazing_features_bgimage\": {\n        \"value\": \"http://localhost/poultry-web/wp-content/uploads/2021/08/Group-25.png\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-08-13 08:16:52\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', 'bfd4a65d-313c-4604-869f-14d4964525ed', '', '', '2021-08-13 08:16:52', '2021-08-13 08:16:52', '', 0, 'http://localhost/poultry-web/?p=31', 0, 'customize_changeset', '', 0),
(32, 1, '2021-08-13 08:15:50', '2021-08-13 08:15:50', '', 'Group 24', '', 'inherit', 'open', 'closed', '', 'group-24', '', '', '2021-08-13 08:15:50', '2021-08-13 08:15:50', '', 0, 'http://localhost/poultry-web/wp-content/uploads/2021/08/Group-24.png', 0, 'attachment', 'image/png', 0),
(33, 1, '2021-08-13 08:16:28', '2021-08-13 08:16:28', '', 'Group 25', '', 'inherit', 'open', 'closed', '', 'group-25', '', '', '2021-08-13 08:16:28', '2021-08-13 08:16:28', '', 0, 'http://localhost/poultry-web/wp-content/uploads/2021/08/Group-25.png', 0, 'attachment', 'image/png', 0),
(34, 1, '2021-08-13 08:34:43', '2021-08-13 08:34:43', '{\n    \"sirat::vw_mobile_app_pro_plugin_main_banner_section_title\": {\n        \"value\": \"Welcome To Joy\'s poultry app \",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-08-13 08:25:20\"\n    },\n    \"sirat::vw_mobile_app_pro_plugin_main_banner_section_subtitle\": {\n        \"value\": \"Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, \",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-08-13 08:26:17\"\n    },\n    \"sirat::vw_mobile_app_pro_plugin_about_section_subtitle\": {\n        \"value\": \"Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, \",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-08-13 08:26:17\"\n    },\n    \"sirat::vw_mobile_app_pro_plugin_about_icon_image1\": {\n        \"value\": \"http://localhost/poultry-web/wp-content/uploads/2021/08/272-2723071_gr-icons-text-black-chicken-02-rooster.png\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-08-13 08:27:18\"\n    },\n    \"sirat::vw_mobile_app_pro_plugin_about_sec_title1\": {\n        \"value\": \"FARM\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-08-13 08:28:35\"\n    },\n    \"sirat::vw_mobile_app_pro_plugin_about_sec_details1\": {\n        \"value\": \"Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has be\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-08-13 08:28:35\"\n    },\n    \"sirat::vw_mobile_app_pro_plugin_about_icon_image2\": {\n        \"value\": \"http://localhost/poultry-web/wp-content/uploads/2021/08/323-3236283_logistics-comments-supply-icon-png-clipart.png\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-08-13 08:31:27\"\n    },\n    \"sirat::vw_mobile_app_pro_plugin_about_sec_title2\": {\n        \"value\": \"SUPPLY\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-08-13 08:33:16\"\n    },\n    \"sirat::vw_mobile_app_pro_plugin_about_sec_details2\": {\n        \"value\": \"Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has be\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-08-13 08:33:16\"\n    },\n    \"sirat::vw_mobile_app_pro_plugin_about_sec_title3\": {\n        \"value\": \"SHOP & SALE\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-08-13 08:34:16\"\n    },\n    \"sirat::vw_mobile_app_pro_plugin_about_icon_image3\": {\n        \"value\": \"http://localhost/poultry-web/wp-content/uploads/2021/08/523-5230105_discount-shop-png-icon-sale-png-transparent-png.png\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-08-13 08:34:16\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '49c7a8bc-430c-4c08-a784-15e30abd8a38', '', '', '2021-08-13 08:34:43', '2021-08-13 08:34:43', '', 0, 'http://localhost/poultry-web/?p=34', 0, 'customize_changeset', '', 0),
(35, 1, '2021-08-13 08:27:10', '2021-08-13 08:27:10', '', '272-2723071_gr-icons-text-black-chicken-02-rooster', '', 'inherit', 'open', 'closed', '', '272-2723071_gr-icons-text-black-chicken-02-rooster', '', '', '2021-08-13 08:27:10', '2021-08-13 08:27:10', '', 0, 'http://localhost/poultry-web/wp-content/uploads/2021/08/272-2723071_gr-icons-text-black-chicken-02-rooster.png', 0, 'attachment', 'image/png', 0),
(36, 1, '2021-08-13 08:29:53', '2021-08-13 08:29:53', '', '323-3236283_logistics-comments-supply-icon-png-clipart', '', 'inherit', 'open', 'closed', '', '323-3236283_logistics-comments-supply-icon-png-clipart', '', '', '2021-08-13 08:29:53', '2021-08-13 08:29:53', '', 0, 'http://localhost/poultry-web/wp-content/uploads/2021/08/323-3236283_logistics-comments-supply-icon-png-clipart.png', 0, 'attachment', 'image/png', 0),
(37, 1, '2021-08-13 08:33:13', '2021-08-13 08:33:13', '', '523-5230105_discount-shop-png-icon-sale-png-transparent-png', '', 'inherit', 'open', 'closed', '', '523-5230105_discount-shop-png-icon-sale-png-transparent-png', '', '', '2021-08-13 08:33:13', '2021-08-13 08:33:13', '', 0, 'http://localhost/poultry-web/wp-content/uploads/2021/08/523-5230105_discount-shop-png-icon-sale-png-transparent-png.png', 0, 'attachment', 'image/png', 0),
(38, 1, '2021-08-13 08:37:40', '2021-08-13 08:37:40', '{\n    \"sirat::vw_mobile_app_pro_plugin_about_sec_details3\": {\n        \"value\": \"Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has be\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-08-13 08:36:24\"\n    },\n    \"sirat::vw_mobile_app_pro_plugin_main_banner_bgimage\": {\n        \"value\": \"http://localhost/poultry-web/wp-content/uploads/2021/08/indoors-chicken-farm-chicken-feeding.png\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-08-13 08:37:40\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '45fdb792-b39e-49fa-b01e-24ca55323d36', '', '', '2021-08-13 08:37:40', '2021-08-13 08:37:40', '', 0, 'http://localhost/poultry-web/?p=38', 0, 'customize_changeset', '', 0),
(39, 1, '2021-08-13 08:37:27', '2021-08-13 08:37:27', '', 'indoors-chicken-farm-chicken-feeding', '', 'inherit', 'open', 'closed', '', 'indoors-chicken-farm-chicken-feeding', '', '', '2021-08-13 08:37:27', '2021-08-13 08:37:27', '', 0, 'http://localhost/poultry-web/wp-content/uploads/2021/08/indoors-chicken-farm-chicken-feeding.png', 0, 'attachment', 'image/png', 0),
(40, 1, '2021-08-13 08:40:28', '2021-08-13 08:40:28', '{\n    \"sirat::vw_mobile_app_pro_plugin_promo_banner_section_subtitle\": {\n        \"value\": \"Lorem Ipsum is simply dummy text \",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-08-13 08:40:28\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '56bbb692-0a38-46bf-932e-44f1e132e00f', '', '', '2021-08-13 08:40:28', '2021-08-13 08:40:28', '', 0, 'http://localhost/poultry-web/2021/08/13/56bbb692-0a38-46bf-932e-44f1e132e00f/', 0, 'customize_changeset', '', 0),
(41, 1, '2021-08-13 08:45:42', '2021-08-13 08:45:42', '{\n    \"sirat::vw_mobile_app_pro_plugin_amazing_features_section_title\": {\n        \"value\": \"APP FEATURE\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-08-13 08:41:33\"\n    },\n    \"sirat::vw_mobile_app_pro_plugin_amazing_features_section_subtitle\": {\n        \"value\": \"\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-08-13 08:42:16\"\n    },\n    \"sirat::vw_mobile_app_pro_plugin_amazing_features_box_left_title2\": {\n        \"value\": \"CREATIVE DESIGN\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-08-13 08:43:54\"\n    },\n    \"sirat::vw_mobile_app_pro_plugin_amazing_features_box_left_title3\": {\n        \"value\": \"CREATIVE DESIGN\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-08-13 08:43:54\"\n    },\n    \"sirat::vw_mobile_app_pro_plugin_amazing_features_box_right_title1\": {\n        \"value\": \"CREATIVE DESIGN\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-08-13 08:43:54\"\n    },\n    \"sirat::vw_mobile_app_pro_plugin_amazing_features_box_right_title2\": {\n        \"value\": \"CREATIVE DESIGN\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-08-13 08:43:54\"\n    },\n    \"sirat::vw_mobile_app_pro_plugin_amazing_features_box_right_title3\": {\n        \"value\": \"CREATIVE DESIGN\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-08-13 08:44:40\"\n    },\n    \"sirat::vw_mobile_app_pro_plugin_awesome_screenshot_section_subtitle\": {\n        \"value\": \"Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s,\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-08-13 08:45:40\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '7c807844-1de4-40da-b233-d74f7c0acff4', '', '', '2021-08-13 08:45:42', '2021-08-13 08:45:42', '', 0, 'http://localhost/poultry-web/?p=41', 0, 'customize_changeset', '', 0),
(42, 1, '2021-08-13 08:53:45', '2021-08-13 08:53:45', '{\n    \"sirat::vw_mobile_app_pro_plugin_plans_pricing_bgimage\": {\n        \"value\": \"http://localhost/poultry-web/wp-content/uploads/2021/08/Group-25.png\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-08-13 08:46:54\"\n    },\n    \"sirat::vw_mobile_app_pro_plugin_pricing_box_section_title\": {\n        \"value\": \"APP FEATURES\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-08-13 08:46:54\"\n    },\n    \"sirat::vw_mobile_app_pro_plugin_pricing_box_section_subtitle\": {\n        \"value\": \"\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-08-13 08:46:54\"\n    },\n    \"sirat::vw_mobile_app_pro_plugin_pricing_box_title1\": {\n        \"value\": \"features List\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-08-13 08:52:23\"\n    },\n    \"sirat::vw_mobile_app_pro_plugin_pricing_box_subtitle1\": {\n        \"value\": \"features \",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-08-13 08:51:24\"\n    },\n    \"sirat::vw_mobile_app_pro_plugin_pricing_box_price1\": {\n        \"value\": \"features \",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-08-13 08:51:24\"\n    },\n    \"sirat::vw_mobile_app_pro_plugin_pricing_box_price_base1\": {\n        \"value\": \"\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-08-13 08:52:23\"\n    },\n    \"sirat::vw_mobile_app_pro_plugin_plan_box_text11\": {\n        \"value\": \"features Listing will go here\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-08-13 08:50:23\"\n    },\n    \"sirat::vw_mobile_app_pro_plugin_plan_box_text21\": {\n        \"value\": \"features Listing will go here\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-08-13 08:50:23\"\n    },\n    \"sirat::vw_mobile_app_pro_plugin_plan_box_text31\": {\n        \"value\": \"features Listing will go here\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-08-13 08:50:23\"\n    },\n    \"sirat::vw_mobile_app_pro_plugin_plan_box_text51\": {\n        \"value\": \"features Listing will go here\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-08-13 08:50:23\"\n    },\n    \"sirat::vw_mobile_app_pro_plugin_team_title\": {\n        \"value\": \"OUR SCREENSHOTS\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-08-13 08:53:43\"\n    },\n    \"sirat::vw_mobile_app_pro_plugin_team_desc\": {\n        \"value\": \"Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s,\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-08-13 08:53:45\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '00293b71-42c1-4b07-8c49-e4b1bad18524', '', '', '2021-08-13 08:53:45', '2021-08-13 08:53:45', '', 0, 'http://localhost/poultry-web/?p=42', 0, 'customize_changeset', '', 0),
(44, 1, '2021-08-13 09:30:53', '2021-08-13 09:30:53', '', '02', '', 'inherit', 'open', 'closed', '', '02', '', '', '2021-08-13 09:30:53', '2021-08-13 09:30:53', '', 0, 'http://localhost/poultry-web/wp-content/uploads/2021/08/02.jpg', 0, 'attachment', 'image/jpeg', 0),
(45, 1, '2021-08-13 09:43:02', '2021-08-13 09:43:02', '{\n    \"sirat::vw_mobile_app_pro_plugin_amazing_features_box_center_image\": {\n        \"value\": \"http://localhost/poultry-web/wp-content/uploads/2021/08/02.jpg\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-08-13 09:31:57\"\n    },\n    \"sirat::vw_mobile_app_pro_plugin_latestpost_desc\": {\n        \"value\": \"Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s,\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-08-13 09:39:34\"\n    },\n    \"sirat::vw_mobile_app_pro_plugin_records_bgimage\": {\n        \"value\": \"\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-08-13 09:43:02\"\n    },\n    \"sirat::vw_mobile_app_pro_plugin_newsletter_bgimage\": {\n        \"value\": \"http://localhost/poultry-web/wp-content/uploads/2021/08/Mask-Group-3.png\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-08-13 09:43:02\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '5fd32822-edda-45fc-b120-ee3b8f1be826', '', '', '2021-08-13 09:43:02', '2021-08-13 09:43:02', '', 0, 'http://localhost/poultry-web/?p=45', 0, 'customize_changeset', '', 0),
(46, 1, '2021-08-13 09:41:58', '2021-08-13 09:41:58', '', 'Mask Group 3', '', 'inherit', 'open', 'closed', '', 'mask-group-3', '', '', '2021-08-13 09:41:58', '2021-08-13 09:41:58', '', 0, 'http://localhost/poultry-web/wp-content/uploads/2021/08/Mask-Group-3.png', 0, 'attachment', 'image/png', 0),
(47, 1, '2021-08-13 09:48:24', '2021-08-13 09:48:24', '{\n    \"sirat::vw_mobile_app_pro_plugin_newsletter_bgimage\": {\n        \"value\": \"http://localhost/poultry-web/wp-content/uploads/2021/08/indoors-chicken-farm-chicken-feeding.png\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-08-13 09:47:27\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '0566aef0-1c96-454c-a1b5-38cd6e5ffe7e', '', '', '2021-08-13 09:48:24', '2021-08-13 09:48:24', '', 0, 'http://localhost/poultry-web/?p=47', 0, 'customize_changeset', '', 0),
(48, 1, '2021-08-13 09:53:18', '2021-08-13 09:53:18', '{\n    \"sirat::vw_mobile_app_pro_plugin_our_testimonial_bgimage\": {\n        \"value\": \"http://localhost/poultry-web/wp-content/uploads/2021/08/Group-25.png\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-08-13 09:51:10\"\n    },\n    \"sirat::vw_mobile_app_pro_plugin_awesome_screenshot_image1\": {\n        \"value\": \"http://localhost/poultry-web/wp-content/uploads/2021/08/02-1.jpg\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-08-13 09:52:11\"\n    },\n    \"sirat::vw_mobile_app_pro_plugin_awesome_screenshot_image2\": {\n        \"value\": \"http://localhost/poultry-web/wp-content/uploads/2021/08/03.jpg\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-08-13 09:53:09\"\n    },\n    \"sirat::vw_mobile_app_pro_plugin_awesome_screenshot_image3\": {\n        \"value\": \"http://localhost/poultry-web/wp-content/uploads/2021/08/04.jpg\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-08-13 09:53:09\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '24124446-6a96-4d52-bd9b-4865790dc432', '', '', '2021-08-13 09:53:18', '2021-08-13 09:53:18', '', 0, 'http://localhost/poultry-web/?p=48', 0, 'customize_changeset', '', 0),
(49, 1, '2021-08-13 09:51:32', '2021-08-13 09:51:32', '', '02', '', 'inherit', 'open', 'closed', '', '02-2', '', '', '2021-08-13 09:51:32', '2021-08-13 09:51:32', '', 0, 'http://localhost/poultry-web/wp-content/uploads/2021/08/02-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(50, 1, '2021-08-13 09:52:29', '2021-08-13 09:52:29', '', '03', '', 'inherit', 'open', 'closed', '', '03', '', '', '2021-08-13 09:52:29', '2021-08-13 09:52:29', '', 0, 'http://localhost/poultry-web/wp-content/uploads/2021/08/03.jpg', 0, 'attachment', 'image/jpeg', 0),
(51, 1, '2021-08-13 09:52:57', '2021-08-13 09:52:57', '', '04', '', 'inherit', 'open', 'closed', '', '04', '', '', '2021-08-13 09:52:57', '2021-08-13 09:52:57', '', 0, 'http://localhost/poultry-web/wp-content/uploads/2021/08/04.jpg', 0, 'attachment', 'image/jpeg', 0),
(52, 1, '2021-08-13 09:59:01', '2021-08-13 09:59:01', '', '001', '', 'inherit', 'open', 'closed', '', '001', '', '', '2021-08-13 09:59:01', '2021-08-13 09:59:01', '', 0, 'http://localhost/poultry-web/wp-content/uploads/2021/08/001.png', 0, 'attachment', 'image/png', 0),
(53, 1, '2021-08-13 10:02:25', '2021-08-13 10:02:25', '{\n    \"sirat::vw_mobile_app_pro_plugin_awesome_screenshot_image1\": {\n        \"value\": \"http://localhost/poultry-web/wp-content/uploads/2021/08/001.png\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-08-13 09:59:23\"\n    },\n    \"sirat::vw_mobile_app_pro_plugin_awesome_screenshot_image2\": {\n        \"value\": \"http://localhost/poultry-web/wp-content/uploads/2021/08/002.png\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-08-13 10:01:23\"\n    },\n    \"sirat::vw_mobile_app_pro_plugin_awesome_screenshot_image3\": {\n        \"value\": \"http://localhost/poultry-web/wp-content/uploads/2021/08/003.png\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-08-13 10:02:23\"\n    },\n    \"sirat::vw_mobile_app_pro_plugin_awesome_screenshot_image4\": {\n        \"value\": \"http://localhost/poultry-web/wp-content/uploads/2021/08/004.png\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-08-13 10:02:23\"\n    },\n    \"sirat::vw_mobile_app_pro_plugin_awesome_screenshot_image5\": {\n        \"value\": \"http://localhost/poultry-web/wp-content/uploads/2021/08/amezingfeaturesimg-1.png\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-08-13 10:02:23\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '243930f2-7fc1-4524-8c7a-19649f8eb8fb', '', '', '2021-08-13 10:02:25', '2021-08-13 10:02:25', '', 0, 'http://localhost/poultry-web/?p=53', 0, 'customize_changeset', '', 0),
(54, 1, '2021-08-13 10:00:40', '2021-08-13 10:00:40', '', '002', '', 'inherit', 'open', 'closed', '', '002', '', '', '2021-08-13 10:00:40', '2021-08-13 10:00:40', '', 0, 'http://localhost/poultry-web/wp-content/uploads/2021/08/002.png', 0, 'attachment', 'image/png', 0),
(55, 1, '2021-08-13 10:01:22', '2021-08-13 10:01:22', '', '003', '', 'inherit', 'open', 'closed', '', '003', '', '', '2021-08-13 10:01:22', '2021-08-13 10:01:22', '', 0, 'http://localhost/poultry-web/wp-content/uploads/2021/08/003.png', 0, 'attachment', 'image/png', 0),
(56, 1, '2021-08-13 10:01:49', '2021-08-13 10:01:49', '', '004', '', 'inherit', 'open', 'closed', '', '004', '', '', '2021-08-13 10:01:49', '2021-08-13 10:01:49', '', 0, 'http://localhost/poultry-web/wp-content/uploads/2021/08/004.png', 0, 'attachment', 'image/png', 0),
(57, 1, '2021-08-13 10:02:15', '2021-08-13 10:02:15', '', 'amezingfeaturesimg (1)', '', 'inherit', 'open', 'closed', '', 'amezingfeaturesimg-1', '', '', '2021-08-13 10:02:15', '2021-08-13 10:02:15', '', 0, 'http://localhost/poultry-web/wp-content/uploads/2021/08/amezingfeaturesimg-1.png', 0, 'attachment', 'image/png', 0),
(59, 1, '2021-08-13 11:26:58', '2021-08-13 11:26:58', '{\n    \"sirat::vw_mobile_app_pro_plugin_awesome_screenshot_image2\": {\n        \"value\": \"http://localhost/poultry-web/wp-content/uploads/2021/08/004.png\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-08-13 11:26:43\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', 'daf900c1-561d-4a1e-855f-c31bc3f078a1', '', '', '2021-08-13 11:26:58', '2021-08-13 11:26:58', '', 0, 'http://localhost/poultry-web/?p=59', 0, 'customize_changeset', '', 0),
(60, 1, '2021-08-13 11:32:43', '2021-08-13 11:32:43', '', '005', '', 'inherit', 'open', 'closed', '', '005', '', '', '2021-08-13 11:32:43', '2021-08-13 11:32:43', '', 0, 'http://localhost/poultry-web/wp-content/uploads/2021/08/005.png', 0, 'attachment', 'image/png', 0),
(61, 1, '2021-08-13 11:32:55', '2021-08-13 11:32:55', '{\n    \"sirat::vw_mobile_app_pro_plugin_amazing_features_box_center_image\": {\n        \"value\": \"http://localhost/poultry-web/wp-content/uploads/2021/08/005.png\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-08-13 11:32:55\"\n    },\n    \"sirat::vw_mobile_app_pro_plugin_awesome_screenshot_image5\": {\n        \"value\": \"\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-08-13 11:32:55\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '515ef463-a9c7-4672-86ed-e95af6a3f52a', '', '', '2021-08-13 11:32:55', '2021-08-13 11:32:55', '', 0, 'http://localhost/poultry-web/2021/08/13/515ef463-a9c7-4672-86ed-e95af6a3f52a/', 0, 'customize_changeset', '', 0),
(62, 1, '2021-08-13 12:21:36', '2021-08-13 12:21:36', '{\n    \"sirat::vw_mobile_app_pro_plugin_testimonial_desc\": {\n        \"value\": \"Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s,\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-08-13 12:19:42\"\n    },\n    \"sirat::vw_mobile_app_pro_plugin_records_desc\": {\n        \"value\": \"Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s,\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-08-13 12:19:42\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', 'c5dfe9fd-0c33-41a1-8bad-5d6fff9f6ee8', '', '', '2021-08-13 12:21:36', '2021-08-13 12:21:36', '', 0, 'http://localhost/poultry-web/?p=62', 0, 'customize_changeset', '', 0),
(63, 1, '2021-08-13 12:35:00', '2021-08-13 12:35:00', '{\n    \"sirat::vw_mobile_app_pro_plugin_hi_first_color\": {\n        \"value\": \"#128bcf\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-08-13 12:33:02\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '94e6c1eb-12b9-4719-abe5-c52a9e223be7', '', '', '2021-08-13 12:35:00', '2021-08-13 12:35:00', '', 0, 'http://localhost/poultry-web/?p=63', 0, 'customize_changeset', '', 0),
(64, 1, '2021-08-13 12:38:16', '2021-08-13 12:38:16', '{\n    \"sirat::vw_mobile_app_pro_plugin_hi_third_color\": {\n        \"value\": \"#128bcf\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-08-13 12:38:16\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '0e907ecb-7fd2-4164-8f16-c9efd7b9ffe7', '', '', '2021-08-13 12:38:16', '2021-08-13 12:38:16', '', 0, 'http://localhost/poultry-web/2021/08/13/0e907ecb-7fd2-4164-8f16-c9efd7b9ffe7/', 0, 'customize_changeset', '', 0),
(65, 1, '2021-08-14 04:29:11', '2021-08-14 04:29:11', '{\n    \"sirat::vw_mobile_app_pro_plugin_awesome_screenshot_image2\": {\n        \"value\": \"http://localhost/poultry-web/wp-content/uploads/2021/08/001.png\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-08-14 04:29:05\"\n    },\n    \"sirat::vw_mobile_app_pro_plugin_awesome_screenshot_image4\": {\n        \"value\": \"http://localhost/poultry-web/wp-content/uploads/2021/08/005.png\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-08-14 04:29:05\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '56609a1a-f3aa-4051-b2c5-dd512429cedf', '', '', '2021-08-14 04:29:11', '2021-08-14 04:29:11', '', 0, 'http://localhost/poultry-web/?p=65', 0, 'customize_changeset', '', 0),
(66, 1, '2021-08-14 09:00:32', '2021-08-14 09:00:32', '{\n    \"sirat::vw_mobile_app_pro_plugin_radio_post_enable\": {\n        \"value\": \"Disable\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-08-14 09:00:32\"\n    },\n    \"sirat::vw_mobile_app_pro_plugin_radio_boxed_full_layout\": {\n        \"value\": \"full-Width\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-08-14 05:15:26\"\n    },\n    \"sirat::vw_mobile_app_pro_plugin_address\": {\n        \"value\": \"Piravom, Pin 686664\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-08-14 08:58:02\"\n    },\n    \"sirat::vw_mobile_app_pro_plugin_contactpage_email\": {\n        \"value\": \"joyspoultryapp@gmail.com\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-08-14 08:59:02\"\n    },\n    \"sirat::vw_mobile_app_pro_plugin_contactpage_phone\": {\n        \"value\": \"+918457146508\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-08-14 09:00:02\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '1654d1a0-7f62-45cd-8cbb-7e2864a36a4e', '', '', '2021-08-14 09:00:32', '2021-08-14 09:00:32', '', 0, 'http://localhost/poultry-web/?p=66', 0, 'customize_changeset', '', 0),
(67, 1, '2021-08-14 09:11:37', '2021-08-14 09:11:37', '{\n    \"sirat::vw_mobile_app_pro_plugin_records_box_subtitle2\": {\n        \"value\": \"load arrived\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-08-14 09:11:00\"\n    },\n    \"sirat::vw_mobile_app_pro_plugin_records_box_subtitle3\": {\n        \"value\": \"staff\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-08-14 09:11:00\"\n    },\n    \"sirat::vw_mobile_app_pro_plugin_records_box_subtitle4\": {\n        \"value\": \"Team support\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-08-14 09:11:37\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', 'e95be86d-1cd1-4873-b4b1-8fb5839592b9', '', '', '2021-08-14 09:11:37', '2021-08-14 09:11:37', '', 0, 'http://localhost/poultry-web/?p=67', 0, 'customize_changeset', '', 0),
(68, 1, '2021-08-14 12:03:25', '2021-08-14 12:03:25', '{\n    \"sirat::vw_mobile_app_pro_plugin_plans_pricing_enable\": {\n        \"value\": \"Enable\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-08-14 10:26:21\"\n    },\n    \"sirat::vw_mobile_app_pro_plugin_amazing_features_box_left_icon1\": {\n        \"value\": \"far fa-object-ungroup\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-08-14 10:44:59\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', 'ee24421c-960a-4cc6-bfb1-752037ad041f', '', '', '2021-08-14 12:03:25', '2021-08-14 12:03:25', '', 0, 'http://localhost/poultry-web/?p=68', 0, 'customize_changeset', '', 0),
(69, 1, '2021-08-25 11:33:03', '2021-08-25 11:33:03', '{\n    \"sirat::vw_mobile_app_pro_plugin_radio_boxed_full_layout\": {\n        \"value\": \"full-Width\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-08-25 10:53:48\"\n    },\n    \"sirat::vw_mobile_app_pro_plugin_footer_copy\": {\n        \"value\": \"Powered by Bharatham IT Solutions PVT.LTD.\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-08-25 11:33:03\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '3ce3a051-2e12-4895-874e-cebca574dd2f', '', '', '2021-08-25 11:33:03', '2021-08-25 11:33:03', '', 0, 'http://localhost/poultry-web/?p=69', 0, 'customize_changeset', '', 0),
(71, 1, '2021-08-26 07:22:43', '2021-08-26 07:22:43', '{\n    \"sirat::vw_mobile_app_pro_plugin_plans_price_one_bgcolor\": {\n        \"value\": \"#128bcf\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-08-26 07:22:43\"\n    },\n    \"sirat::vw_mobile_app_pro_plugin_plans_price_two_bgcolor\": {\n        \"value\": \"#41c69a\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-08-26 07:22:43\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', 'e5bd8de9-49cc-4eb8-bad1-95135ef8476b', '', '', '2021-08-26 07:22:43', '2021-08-26 07:22:43', '', 0, 'http://localhost/poultry-web/2021/08/26/e5bd8de9-49cc-4eb8-bad1-95135ef8476b/', 0, 'customize_changeset', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `pd_termmeta`
--

CREATE TABLE `pd_termmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL,
  `term_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pd_terms`
--

CREATE TABLE `pd_terms` (
  `term_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pd_terms`
--

INSERT INTO `pd_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Uncategorized', 'uncategorized', 0);

-- --------------------------------------------------------

--
-- Table structure for table `pd_term_relationships`
--

CREATE TABLE `pd_term_relationships` (
  `object_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `term_taxonomy_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `term_order` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pd_term_relationships`
--

INSERT INTO `pd_term_relationships` (`object_id`, `term_taxonomy_id`, `term_order`) VALUES
(1, 1, 0),
(12, 1, 0),
(14, 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `pd_term_taxonomy`
--

CREATE TABLE `pd_term_taxonomy` (
  `term_taxonomy_id` bigint(20) UNSIGNED NOT NULL,
  `term_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `count` bigint(20) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pd_term_taxonomy`
--

INSERT INTO `pd_term_taxonomy` (`term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 3);

-- --------------------------------------------------------

--
-- Table structure for table `pd_usermeta`
--

CREATE TABLE `pd_usermeta` (
  `umeta_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pd_usermeta`
--

INSERT INTO `pd_usermeta` (`umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'admin'),
(2, 1, 'first_name', ''),
(3, 1, 'last_name', ''),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'syntax_highlighting', 'true'),
(7, 1, 'comment_shortcuts', 'false'),
(8, 1, 'admin_color', 'fresh'),
(9, 1, 'use_ssl', '0'),
(10, 1, 'show_admin_bar_front', 'true'),
(11, 1, 'locale', ''),
(12, 1, 'pd_capabilities', 'a:1:{s:13:\"administrator\";b:1;}'),
(13, 1, 'pd_user_level', '10'),
(14, 1, 'dismissed_wp_pointers', ''),
(15, 1, 'show_welcome_panel', '1'),
(16, 1, 'session_tokens', 'a:1:{s:64:\"195459eac583597eec9adc26f280319d9ab0684e1d8d74f632c5643fb4e44fae\";a:4:{s:10:\"expiration\";i:1630643857;s:2:\"ip\";s:3:\"::1\";s:2:\"ua\";s:114:\"Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.159 Safari/537.36\";s:5:\"login\";i:1630471057;}}'),
(17, 1, 'wp_admindashboard_quick_press_last_post_id', '4'),
(18, 1, 'wp_adminuser-settings', 'libraryContent=browse'),
(19, 1, 'wp_adminuser-settings-time', '1628843691'),
(20, 1, 'pd_dashboard_quick_press_last_post_id', '70'),
(21, 1, 'pd_user-settings', 'libraryContent=browse'),
(22, 1, 'pd_user-settings-time', '1628854032'),
(23, 1, 'managenav-menuscolumnshidden', 'a:5:{i:0;s:11:\"link-target\";i:1;s:11:\"css-classes\";i:2;s:3:\"xfn\";i:3;s:11:\"description\";i:4;s:15:\"title-attribute\";}'),
(24, 1, 'metaboxhidden_nav-menus', 'a:4:{i:0;s:26:\"add-post-type-testimonials\";i:1;s:18:\"add-post-type-team\";i:2;s:12:\"add-post_tag\";i:3;s:15:\"add-post_format\";}');

-- --------------------------------------------------------

--
-- Table structure for table `pd_users`
--

CREATE TABLE `pd_users` (
  `ID` bigint(20) UNSIGNED NOT NULL,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT 0,
  `display_name` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pd_users`
--

INSERT INTO `pd_users` (`ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, 'admin', '$P$BpgI4roQET1Is7VWPOy2Nq1WDqNY15.', 'admin', 'sharon.bharathamitsolution@gmail.com', 'http://localhost/poultry-web/wordpress', '2021-08-13 05:58:52', '', 0, 'admin');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `pd_commentmeta`
--
ALTER TABLE `pd_commentmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `comment_id` (`comment_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `pd_comments`
--
ALTER TABLE `pd_comments`
  ADD PRIMARY KEY (`comment_ID`),
  ADD KEY `comment_post_ID` (`comment_post_ID`),
  ADD KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  ADD KEY `comment_date_gmt` (`comment_date_gmt`),
  ADD KEY `comment_parent` (`comment_parent`),
  ADD KEY `comment_author_email` (`comment_author_email`(10));

--
-- Indexes for table `pd_links`
--
ALTER TABLE `pd_links`
  ADD PRIMARY KEY (`link_id`),
  ADD KEY `link_visible` (`link_visible`);

--
-- Indexes for table `pd_options`
--
ALTER TABLE `pd_options`
  ADD PRIMARY KEY (`option_id`),
  ADD UNIQUE KEY `option_name` (`option_name`),
  ADD KEY `autoload` (`autoload`);

--
-- Indexes for table `pd_postmeta`
--
ALTER TABLE `pd_postmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `post_id` (`post_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `pd_posts`
--
ALTER TABLE `pd_posts`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `post_name` (`post_name`(191)),
  ADD KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  ADD KEY `post_parent` (`post_parent`),
  ADD KEY `post_author` (`post_author`);

--
-- Indexes for table `pd_termmeta`
--
ALTER TABLE `pd_termmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `term_id` (`term_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `pd_terms`
--
ALTER TABLE `pd_terms`
  ADD PRIMARY KEY (`term_id`),
  ADD KEY `slug` (`slug`(191)),
  ADD KEY `name` (`name`(191));

--
-- Indexes for table `pd_term_relationships`
--
ALTER TABLE `pd_term_relationships`
  ADD PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  ADD KEY `term_taxonomy_id` (`term_taxonomy_id`);

--
-- Indexes for table `pd_term_taxonomy`
--
ALTER TABLE `pd_term_taxonomy`
  ADD PRIMARY KEY (`term_taxonomy_id`),
  ADD UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  ADD KEY `taxonomy` (`taxonomy`);

--
-- Indexes for table `pd_usermeta`
--
ALTER TABLE `pd_usermeta`
  ADD PRIMARY KEY (`umeta_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `pd_users`
--
ALTER TABLE `pd_users`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `user_login_key` (`user_login`),
  ADD KEY `user_nicename` (`user_nicename`),
  ADD KEY `user_email` (`user_email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `pd_commentmeta`
--
ALTER TABLE `pd_commentmeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pd_comments`
--
ALTER TABLE `pd_comments`
  MODIFY `comment_ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `pd_links`
--
ALTER TABLE `pd_links`
  MODIFY `link_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pd_options`
--
ALTER TABLE `pd_options`
  MODIFY `option_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=320;

--
-- AUTO_INCREMENT for table `pd_postmeta`
--
ALTER TABLE `pd_postmeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=205;

--
-- AUTO_INCREMENT for table `pd_posts`
--
ALTER TABLE `pd_posts`
  MODIFY `ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=72;

--
-- AUTO_INCREMENT for table `pd_termmeta`
--
ALTER TABLE `pd_termmeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pd_terms`
--
ALTER TABLE `pd_terms`
  MODIFY `term_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `pd_term_taxonomy`
--
ALTER TABLE `pd_term_taxonomy`
  MODIFY `term_taxonomy_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `pd_usermeta`
--
ALTER TABLE `pd_usermeta`
  MODIFY `umeta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `pd_users`
--
ALTER TABLE `pd_users`
  MODIFY `ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
